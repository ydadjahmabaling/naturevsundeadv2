import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 * Nature vs Undead — Full Edition v3 (sprite-fixed)
 * Supabase Auth + 5-level campaign + EXP system + collectibles + 6 plants.
 * Assets: every png/jpg under the launch folder (and its parent) is indexed by filename,
 * so it works whether you launch from the workspace root or the project folder.
 * Run:  java main.java   (JDK 11+)
 */
public class main extends JFrame implements GameCallback {

    // ===================== SUPABASE =====================
    private static final String SUPABASE_URL      = "https://swxofgugheiftbcntjng.supabase.co";
    private static final String SUPABASE_ANON_KEY = "sb_publishable_XzcgjNdjTeqKBJBWyUOUgA_NXFsBQQX";

    // ===================== ASSET INDEX =====================
    private final Map<String, Path> assetIndex = new HashMap<>();
    private Path saveFile = Paths.get("nvs_save.properties");

    // ===================== CORE =====================
    private CardLayout cardLayout;
    private JPanel mainContainer;

    // Assets
    private BufferedImage backgroundImage;
    private BufferedImage logoImage;
    private BufferedImage textureImage;
    private BufferedImage plantPeaImg, plantSunImg, plantNutImg, plantSnowImg, plantCherryImg, plantRepeaterImg;
    private BufferedImage zombieImg, sunImg, peaImg;

    // Screens
    private LoadingScreen loadingScreen;
    private AuthScreen authScreen;
    private MainMenuScreen menuScreen;
    private LevelSelectScreen levelScreen;
    private SettingsScreen settingsScreen;
    private AchievementsScreen achScreen;
    private GamePanel gamePanel;

    // State
    private String loggedInUser = "";
    private String accessToken = "";
    private boolean isFullScreen = false;

    // Save data
    private Properties save = new Properties();
    private int unlockedLevel = 1;
    private int[] stars = new int[5];
    private int totalKills = 0;
    private long totalSunCollected = 0;

    // Profile / progression
    private int playerLevel = 1;
    private long xp = 0;
    private long coins = 0;

    // Debug overlay
    private int fps, frameCount;
    private BufferedImage menuBgCache;
    private int menuBgW, menuBgH;
    private long lastTimeMillis;
    private String fpsString = "FPS: 0";
    private String ramString = "RAM: 0MB";

    public main() {
        setTitle("Nature vs Undead");
        setSize(1280, 800);
        setMinimumSize(new Dimension(1100, 720));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);
        mainContainer.setBackground(new Color(12, 16, 12));

        buildAssetIndex();
        loadProgress();
        saveTimer.setRepeats(false);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> { if (saveDirty) doPersist(); }));

        loadingScreen = new LoadingScreen();
        mainContainer.add(loadingScreen, "LOADING");

        setContentPane(mainContainer);
        setupDebugOverlay();
        startDebugLoop();

        cardLayout.show(mainContainer, "LOADING");
        loadAssetsAsync();
    }

    // ===================== ASSET LOADING =====================
    private static String normalizeAssetName(String value) {
        return value.toLowerCase(java.util.Locale.ROOT)
            .replace(" ", "").replace("_", "").replace("-", "");
    }

    /** Walk the launch folder (and its parent) once and index every image by normalized filename. */
    private void buildAssetIndex() {
        Path cwd = Paths.get("").toAbsolutePath();
        List<Path> starts = new ArrayList<>();
        starts.add(cwd);
        if (cwd.getParent() != null) starts.add(cwd.getParent());

        for (Path start : starts) {
            try (java.util.stream.Stream<Path> s = Files.walk(start, 4)) {
                s.filter(Files::isRegularFile).forEach(p -> {
                    String fn = p.getFileName().toString();
                    String low = fn.toLowerCase(java.util.Locale.ROOT);
                    if (low.endsWith(".png") || low.endsWith(".jpg") || low.endsWith(".jpeg")) {
                        assetIndex.putIfAbsent(normalizeAssetName(fn), p);
                    }
                });
            } catch (Exception ignored) { }
            if (!assetIndex.isEmpty()) break;
        }
        System.out.println("[assets] indexed " + assetIndex.size() + " images (one-time scan)");
    }

    private BufferedImage loadImage(String name, int maxW, int maxH) {
        Path p = assetIndex.get(normalizeAssetName(name));
        if (p == null) return null;
        try {
            BufferedImage image = ImageIO.read(p.toFile());
            if (image == null) return null;
            return shrink(image, maxW, maxH);
        } catch (Exception e) {
            System.out.println("[assets] failed " + p + ": " + e.getMessage());
            return null;
        }
    }

    private BufferedImage loadFirst(int maxW, int maxH, String... names) {
        for (String n : names) {
            BufferedImage img = loadImage(n, maxW, maxH);
            if (img != null) return img;
        }
        System.out.println("[assets] MISSING: " + names[0]);
        return null;
    }

    static BufferedImage toArgb(BufferedImage src) {
        if (src.getType() == BufferedImage.TYPE_INT_ARGB) return src;
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    /** Trims transparent padding so the sprite sits flush on the ground and is sized by the zombie itself. */
    static BufferedImage cropToContent(BufferedImage src) {
        if (src == null) return null;
        int w = src.getWidth(), h = src.getHeight();
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((src.getRGB(x, y) >>> 24) > 12) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) return src;
        int cw = maxX - minX + 1, ch = maxY - minY + 1;
        BufferedImage out = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, cw, ch, minX, minY, minX + cw, minY + ch, null);
        g.dispose();
        return out;
    }

    /** Only ever makes an image smaller (frees RAM), never bigger. */
    static BufferedImage shrink(BufferedImage src, int maxW, int maxH) {
        if (src.getWidth() <= maxW && src.getHeight() <= maxH) return toArgb(src);
        double s = Math.min((double) maxW / src.getWidth(), (double) maxH / src.getHeight());
        return scaleHQ(src, Math.max(1, (int) (src.getWidth() * s)), Math.max(1, (int) (src.getHeight() * s)));
    }

    /** Progressive halving = good quality without bicubic cost. Used only at load / cache time. */
    static BufferedImage scaleHQ(BufferedImage src, int w, int h) {
        BufferedImage cur = src;
        int cw = src.getWidth(), ch = src.getHeight();
        while (cw > w * 2 || ch > h * 2) {
            cw = Math.max(w, cw / 2);
            ch = Math.max(h, ch / 2);
            cur = scaleStep(cur, cw, ch);
        }
        return scaleStep(cur, w, h);
    }

    private static BufferedImage scaleStep(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }

    private void loadAssetsAsync() {
        SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
            @Override protected Void doInBackground() throws Exception {
                loadingScreen.setStatus("Waking up the garden...");
                backgroundImage = loadFirst(1920, 1080, "background.png");
                publish(12);
                Thread.sleep(150);

                loadingScreen.setStatus("Painting the logo...");
                logoImage = loadFirst(700, 300, "logo.png");
                textureImage = loadFirst(512, 512, "texture.png");
                publish(26);
                Thread.sleep(150);

                loadingScreen.setStatus("Growing plants...");
                plantPeaImg      = loadFirst(256, 256, "peashooter.png", "pea shooter.png");
                plantSunImg      = loadFirst(256, 256, "sunflower.png");
                plantNutImg      = loadFirst(256, 256, "wallnut.png", "walnut.png");
                plantSnowImg     = loadFirst(256, 256, "snowpea.png", "snow pea.png");
                plantCherryImg   = loadFirst(256, 256, "cherry bomb.png", "cherrybomb.png");
                plantRepeaterImg = loadFirst(256, 256, "repeater.png", "multi headed pea shooter.png", "multiheadedpeashooter.png");
                publish(52);
                Thread.sleep(150);

                loadingScreen.setStatus("Raising the undead...");
                zombieImg = cropToContent(loadFirst(512, 512, "zombies.png", "zombie.png", "basiczombie.png", "zombie1.png"));
                sunImg    = loadFirst(256, 256, "sun.png", "sundrop.png");
                peaImg    = loadFirst(256, 256, "pea.png", "peaball.png", "bullet.png");
                publish(72);
                Thread.sleep(150);

                loadingScreen.setStatus("Sharpening lawn mowers...");
                publish(100);
                Thread.sleep(300);
                return null;
            }
            @Override protected void process(List<Integer> chunks) {
                loadingScreen.setProgress(chunks.get(chunks.size() - 1));
            }
            @Override protected void done() {
                authScreen    = new AuthScreen();
                menuScreen    = new MainMenuScreen();
                levelScreen   = new LevelSelectScreen();
                settingsScreen= new SettingsScreen();
                achScreen     = new AchievementsScreen();

                mainContainer.add(authScreen, "AUTH");
                mainContainer.add(menuScreen, "MENU");
                mainContainer.add(levelScreen, "LEVELS");
                mainContainer.add(settingsScreen, "SETTINGS");
                mainContainer.add(achScreen, "ACH");
                cardLayout.show(mainContainer, "AUTH");
                loadingScreen.stop();
            }
        };
        worker.execute();
    }

    // ===================== SAVE / PROGRESS =====================
    private void loadProgress() {
        try (InputStream is = Files.newInputStream(saveFile)) {
            save.load(is);
            unlockedLevel = Integer.parseInt(save.getProperty("unlocked", "1"));
            totalKills = Integer.parseInt(save.getProperty("kills", "0"));
            totalSunCollected = Long.parseLong(save.getProperty("sun", "0"));
            playerLevel = Integer.parseInt(save.getProperty("level", "1"));
            xp = Long.parseLong(save.getProperty("xp", "0"));
            coins = Long.parseLong(save.getProperty("coins", "0"));
            for (int i = 0; i < 5; i++) stars[i] = Integer.parseInt(save.getProperty("stars_" + (i+1), "0"));
        } catch (Exception ignored) {}
    }

    private boolean saveDirty = false;
    private final Timer saveTimer = new Timer(1500, e -> doPersist());

    /** Coalesces rapid saves (every kill/coin) into one disk write. */
    private void persistSave() { saveDirty = true; saveTimer.restart(); }

    private void doPersist() {
        saveDirty = false;
        save.setProperty("unlocked", String.valueOf(unlockedLevel));
        save.setProperty("kills", String.valueOf(totalKills));
        save.setProperty("sun", String.valueOf(totalSunCollected));
        save.setProperty("level", String.valueOf(playerLevel));
        save.setProperty("xp", String.valueOf(xp));
        save.setProperty("coins", String.valueOf(coins));
        for (int i = 0; i < 5; i++) save.setProperty("stars_" + (i+1), String.valueOf(stars[i]));
        try (OutputStream os = Files.newOutputStream(saveFile)) {
            save.store(os, "Nature vs Undead save");
        } catch (Exception ignored) {}
    }

    // ===================== EXP / LEVEL SYSTEM =====================
    private int xpToNext() { return 100 + (playerLevel - 1) * 60; }

    void addXp(int amount) {
        if (amount <= 0) return;
        xp += amount;
        boolean leveled = false;
        while (xp >= xpToNext()) {
            xp -= xpToNext();
            playerLevel++;
            leveled = true;
        }
        persistSave();
        if (menuScreen != null && gamePanel == null) menuScreen.refreshUser();
        if (leveled && gamePanel == null && achScreen != null) achScreen.refresh();
    }

    private void addCoins(int amount) {
        if (amount <= 0) return;
        coins += amount;
        persistSave();
    }

    @Override public void onKill() { addXp(12); }

    @Override public void onCollect(int coinAmount, int sunAmount) {
        addCoins(coinAmount);
        addXp(coinAmount / 2);
    }

    // ===================== SUPABASE AUTH =====================
    private static class AuthResult {
        boolean success; String message; Color color;
        AuthResult(boolean s, String m, Color c) { success = s; message = m; color = c; }
    }

    private void performAuth(String action) {
        String email = authScreen.emailField.getText().trim().toLowerCase();
        String password = new String(authScreen.passField.getPassword());

        if (email.isEmpty() || password.isEmpty()) {
            authScreen.setStatus("Please enter both email and password.", Color.ORANGE);
            return;
        }
        if (!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            authScreen.setStatus("Please enter a valid email address.", Color.ORANGE);
            return;
        }
        if (password.length() < 6) {
            authScreen.setStatus("Password must be at least 6 characters.", Color.ORANGE);
            return;
        }

        authScreen.setBusy(true);
        authScreen.setStatus(action.equals("LOGIN") ? "Signing you in..." : "Creating your account...", new Color(120, 220, 255));

        SwingWorker<AuthResult, Void> worker = new SwingWorker<AuthResult, Void>() {
            @Override protected AuthResult doInBackground() {
                try {
                    String endpoint = action.equals("REGISTER")
                            ? "/auth/v1/signup"
                            : "/auth/v1/token?grant_type=password";

                    URL url = URI.create(SUPABASE_URL + endpoint).toURL();
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setRequestProperty("apikey", SUPABASE_ANON_KEY);
                    conn.setRequestProperty("Authorization", "Bearer " + SUPABASE_ANON_KEY);
                    conn.setRequestProperty("Content-Type", "application/json");

                    String json = "{\"email\":\"" + jsonEscape(email)
                                + "\",\"password\":\"" + jsonEscape(password) + "\"}";
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(json.getBytes(StandardCharsets.UTF_8));
                    }

                    int code = conn.getResponseCode();
                    InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line);
                    }
                    String body = sb.toString();

                    if (body.contains("\"access_token\"")) {
                        accessToken = jsonExtract(body, "access_token");
                        return new AuthResult(true, "Welcome!", new Color(140, 255, 140));
                    }
                    if (action.equals("REGISTER") && body.contains("\"id\"") && !body.contains("access_token")) {
                        return new AuthResult(false,
                            "Account created! Check your email to confirm it, then log in.", new Color(140,255,140));
                    }
                    if (body.contains("already registered") || body.contains("already been registered")) {
                        return new AuthResult(false, "That email is already registered. Try logging in.", Color.ORANGE);
                    }
                    if (body.contains("Email not confirmed") || body.contains("email_not_confirmed")) {
                        return new AuthResult(false,
                            "Email not confirmed yet. Open the confirmation link Supabase sent you.", Color.ORANGE);
                    }
                    if (body.contains("Invalid login credentials")) {
                        return new AuthResult(false, "Wrong email or password.", Color.RED);
                    }
                    String msg = jsonExtract(body, "error_description");
                    if (msg.isEmpty()) msg = jsonExtract(body, "msg");
                    if (msg.isEmpty()) msg = jsonExtract(body, "error");
                    if (msg.isEmpty()) msg = "Authentication failed (HTTP " + code + ").";
                    return new AuthResult(false, msg, Color.RED);

                } catch (Exception ex) {
                    return new AuthResult(false,
                        "Network error: " + ex.getMessage() + " (check internet / firewall)", Color.RED);
                }
            }

            @Override protected void done() {
                authScreen.setBusy(false);
                try {
                    AuthResult r = get();
                    if (r.success) {
                        loggedInUser = email;
                        authScreen.setStatus("Welcome back, commander!", new Color(140, 255, 140));
                        menuScreen.refreshUser();
                        new Timer(500, ev -> {
                            ((Timer) ev.getSource()).stop();
                            cardLayout.show(mainContainer, "MENU");
                        }).start();
                    } else {
                        authScreen.setStatus(r.message, r.color);
                    }
                } catch (Exception ex) {
                    authScreen.setStatus("Unexpected error: " + ex.getMessage(), Color.RED);
                }
            }
        };
        worker.execute();
    }

    private static String jsonExtract(String json, String key) {
        String needle = "\"" + key + "\":\"";
        int start = json.indexOf(needle);
        if (start < 0) return "";
        start += needle.length();
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) { sb.append(json.charAt(++i)); continue; }
            if (c == '"') break;
            sb.append(c);
        }
        return sb.toString();
    }

    private static String jsonEscape(String v) {
        StringBuilder sb = new StringBuilder();
        for (char c : v.toCharArray()) {
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.toString();
    }

    // ===================== NAVIGATION =====================
    private void showScreen(String name) { cardLayout.show(mainContainer, name); }

    void openLevel(int levelIndex) {
        if (gamePanel != null) { gamePanel.shutdown(); mainContainer.remove(gamePanel); }
        gamePanel = new GamePanel(LevelConfig.ALL[levelIndex], levelIndex, this,
                plantPeaImg, plantSunImg, plantNutImg, plantSnowImg, plantCherryImg, plantRepeaterImg,
                zombieImg, sunImg, peaImg);
        mainContainer.add(gamePanel, "GAME");
        cardLayout.show(mainContainer, "GAME");
        gamePanel.requestFocusInWindow();
    }

    @Override public void onLevelComplete(int levelIdx, int starCount, int kills, long sunCollected) {
        totalKills += kills;
        totalSunCollected += sunCollected;
        stars[levelIdx] = Math.max(stars[levelIdx], starCount);
        unlockedLevel = Math.max(unlockedLevel, Math.min(5, levelIdx + 2));
        addXp(50 + starCount * 25);
        persistSave();
        levelScreen.refresh();
    }

    @Override public void onGameExit() {
        if (gamePanel != null) { gamePanel.shutdown(); mainContainer.remove(gamePanel); gamePanel = null; }
        if (menuScreen != null) menuScreen.refreshUser();
        levelScreen.refresh();
        if (achScreen != null) achScreen.refresh();
        showScreen("LEVELS");
    }

    private void signOut() {
        loggedInUser = "";
        accessToken = "";
        authScreen.reset();
        showScreen("AUTH");
    }

    // ===================== FULLSCREEN =====================
    private void toggleFullScreen() {
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        dispose();
        if (!isFullScreen) {
            setUndecorated(true);
            gd.setFullScreenWindow(this);
            isFullScreen = true;
        } else {
            setUndecorated(false);
            gd.setFullScreenWindow(null);
            setSize(1280, 800);
            setLocationRelativeTo(null);
            isFullScreen = false;
        }
        setVisible(true);
    }

    // ===================== DEBUG OVERLAY =====================
    private void setupDebugOverlay() {
        JPanel glass = new JPanel() {
            private final Font f = new Font(Font.MONOSPACED, Font.BOLD, 13);
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 160));
                g2.fillRoundRect(5, 5, 190, 52, 10, 10);
                g2.setColor(new Color(120, 255, 140));
                g2.setFont(f);
                g2.drawString(fpsString, 15, 24);
                g2.drawString(ramString, 15, 44);
            }
        };
        glass.setOpaque(false);
        setGlassPane(glass);
        glass.setVisible(true);
    }

    private void startDebugLoop() {
        lastTimeMillis = System.currentTimeMillis();
        new Timer(1000, e -> {
            fps = frameCount; frameCount = 0;
            fpsString = "FPS: " + fps;
            Runtime rt = Runtime.getRuntime();
            ramString = "RAM: " + (rt.totalMemory() - rt.freeMemory()) / 1048576 + "MB";
            getGlassPane().repaint(0, 0, 210, 64);
        }).start();
    }

    // =====================================================================
    //  LOADING SCREEN
    // =====================================================================
    class LoadingScreen extends JPanel {
        private int progress = 0;
        private String status = "Initializing...";
        private double angle = 0;
        private final String[] tips = {
            "Tip: Sunflowers are your economy. Plant them early!",
            "Tip: Wall-nuts stall zombies while peashooters do the work.",
            "Tip: Cherry bombs explode in a 3x3 area — great for crowds.",
            "Tip: Snow peas slow zombies to a crawl.",
            "Tip: Repeater fires two peas per volley.",
            "Tip: Zombies drop coins. Click them before they vanish!",
            "Tip: Kills and coins earn you XP. Level up, commander!"
        };
        private int tipIdx = 0;
        private float pulse = 0;
        private Timer animTimer, tipTimer;

        LoadingScreen() {
            setLayout(new BorderLayout());
            setBackground(new Color(8, 14, 9));
            animTimer = new Timer(33, e -> {
                angle += 0.18;
                pulse += 0.10f;
                repaint();
            });
            tipTimer = new Timer(3200, e -> { tipIdx = (tipIdx + 1) % tips.length; repaint(); });
            animTimer.start();
            tipTimer.start();
        }

        void stop() { animTimer.stop(); tipTimer.stop(); }

        void setProgress(int p) { progress = p; repaint(); }
        void setStatus(String s) { status = s; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int W = getWidth(), H = getHeight();

            float t = (float) Math.sin(pulse) * 0.5f + 0.5f;
            GradientPaint bg = new GradientPaint(0, 0, new Color(10 + (int)(10*t), 26, 12),
                    W, H, new Color(6, 12, 8));
            g2.setPaint(bg);
            g2.fillRect(0, 0, W, H);

            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.10f));
            for (int i = 0; i < 8; i++) {
                double a = angle * 0.4 + i * 0.8;
                int ox = (int)(W/2 + Math.cos(a) * (180 + i*45));
                int oy = (int)(H/2 + Math.sin(a * 0.7) * (120 + i*30));
                g2.setColor(i % 2 == 0 ? new Color(120, 220, 90) : new Color(90, 160, 255));
                g2.fillOval(ox, oy, 40 + i * 6, 40 + i * 6);
            }
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));

            RadialGradientPaint vg = new RadialGradientPaint(
                    new Point(W/2, H/2), Math.max(W, H) * 0.7f,
                    new float[]{0f, 1f}, new Color[]{new Color(0,0,0,0), new Color(0,0,0,160)});
            g2.setPaint(vg);
            g2.fillRect(0, 0, W, H);

            int cx = W / 2, cy = H / 2 - 40;

            String title = "NATURE VS UNDEAD";
            g2.setFont(new Font("Impact", Font.PLAIN, 58));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(new Color(140, 255, 90, 40));
            g2.drawString(title, cx - fm.stringWidth(title)/2, cy - 60);
            g2.setColor(new Color(20, 40, 20, 220));
            g2.drawString(title, cx - fm.stringWidth(title)/2 + 3, cy - 60 + 3);
            g2.setPaint(new GradientPaint(cx - 300, cy, new Color(190, 255, 110),
                    cx + 300, cy, new Color(90, 220, 90)));
            g2.drawString(title, cx - fm.stringWidth(title)/2, cy - 60);

            int r = 46;
            g2.setStroke(new BasicStroke(7, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(255, 255, 255, 35));
            g2.drawArc(cx - r, cy - 10, r * 2, r * 2, 0, 360);
            g2.setColor(new Color(150, 255, 100));
            g2.drawArc(cx - r, cy - 10, r * 2, r * 2, (int)Math.toDegrees(angle) % 360, 110);

            int bw = 460, bh = 16, bx = cx - bw/2, by = cy + 70;
            g2.setColor(new Color(255, 255, 255, 30));
            g2.fillRoundRect(bx, by, bw, bh, bh, bh);
            if (progress > 0) {
                g2.setPaint(new GradientPaint(bx, by, new Color(120, 230, 90), bx + bw, by, new Color(60, 180, 255)));
                g2.fillRoundRect(bx, by, (int)(bw * progress / 100.0), bh, bh, bh);
            }
            g2.setColor(new Color(255, 255, 255, 90));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(bx, by, bw, bh, bh, bh);

            g2.setFont(new Font("Arial", Font.BOLD, 14));
            g2.setColor(new Color(200, 255, 200));
            g2.drawString(progress + "%", cx + bw/2 + 14, by + bh - 3);
            g2.setColor(new Color(170, 200, 170));
            g2.drawString(status, cx - fm.stringWidth(status) / 2 + 60, by + bh + 28);
            g2.setFont(new Font("Arial", Font.ITALIC, 14));
            g2.setColor(new Color(140, 160, 140));
            String tip = tips[tipIdx];
            g2.drawString(tip, cx - g2.getFontMetrics().stringWidth(tip)/2, H - 60);
        }
    }

    // =====================================================================
    //  AUTH SCREEN
    // =====================================================================
    class AuthScreen extends JPanel {
        RoundedTextField emailField;
        JPasswordField passField;
        private JLabel statusLabel;
        private GradientButton loginBtn, registerBtn;

        AuthScreen() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0;
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.anchor = GridBagConstraints.CENTER;

            if (logoImage != null) {
                add(new JLabel(new ImageIcon(scaleImage(logoImage, 480, 170))), gbc);
            } else {
                JLabel t = new JLabel("NATURE VS UNDEAD");
                t.setFont(new Font("Impact", Font.PLAIN, 42));
                t.setForeground(new Color(190, 255, 110));
                add(t, gbc);
            }

            gbc.gridy++;
            JLabel sub = new JLabel("Sign in to defend the garden");
            sub.setForeground(new Color(160, 190, 160));
            sub.setFont(new Font("Arial", Font.PLAIN, 15));
            add(sub, gbc);

            gbc.gridy++;
            RoundedPanel card = new RoundedPanel(new Color(18, 28, 18, 220), new Color(120, 220, 120, 60), 24);
            card.setLayout(new GridBagLayout());
            card.setPreferredSize(new Dimension(460, 340));
            GridBagConstraints c = new GridBagConstraints();
            c.insets = new Insets(8, 14, 8, 14);
            c.fill = GridBagConstraints.HORIZONTAL;
            c.gridx = 0; c.gridy = 0; c.gridwidth = 2;

            statusLabel = new JLabel("Enter your account details.", SwingConstants.CENTER);
            statusLabel.setForeground(new Color(200, 220, 200));
            statusLabel.setFont(new Font("Arial", Font.PLAIN, 13));
            card.add(statusLabel, c);

            c.gridy++; c.gridwidth = 1; c.fill = GridBagConstraints.NONE; c.anchor = GridBagConstraints.WEST;
            JLabel el = new JLabel("EMAIL");
            el.setForeground(new Color(150, 220, 150));
            el.setFont(new Font("Arial", Font.BOLD, 12));
            card.add(el, c);
            c.gridy++; c.fill = GridBagConstraints.HORIZONTAL; c.gridwidth = 2;
            emailField = new RoundedTextField();
            card.add(emailField, c);

            c.gridy++; c.fill = GridBagConstraints.NONE; c.gridwidth = 1;
            JLabel pl = new JLabel("PASSWORD");
            pl.setForeground(new Color(150, 220, 150));
            pl.setFont(new Font("Arial", Font.BOLD, 12));
            card.add(pl, c);
            c.gridy++; c.fill = GridBagConstraints.HORIZONTAL; c.gridwidth = 2;
            passField = new JPasswordField();
            passField.setEchoChar('•');
            passField.setFont(new Font("Arial", Font.PLAIN, 16));
            passField.setBackground(new Color(30, 42, 30));
            passField.setForeground(Color.WHITE);
            passField.setCaretColor(new Color(150, 255, 150));
            passField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(90, 140, 90), 1, true),
                    new EmptyBorder(8, 12, 8, 12)));
            card.add(passField, c);

            c.gridy++; c.fill = GridBagConstraints.NONE; c.anchor = GridBagConstraints.WEST; c.gridwidth = 1;
            JCheckBox showPass = new JCheckBox("Show password");
            showPass.setOpaque(false);
            showPass.setForeground(new Color(160, 190, 160));
            showPass.setFocusPainted(false);
            showPass.addActionListener(e -> passField.setEchoChar(showPass.isSelected() ? (char)0 : '•'));
            card.add(showPass, c);

            c.gridy++; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL; c.insets = new Insets(14, 14, 6, 14);
            loginBtn = new GradientButton("LOG IN", new Color(70, 180, 90), new Color(40, 130, 60));
            loginBtn.setPreferredSize(new Dimension(0, 46));
            loginBtn.addActionListener(e -> performAuth("LOGIN"));
            card.add(loginBtn, c);

            c.gridy++; c.insets = new Insets(4, 14, 14, 14);
            registerBtn = new GradientButton("CREATE ACCOUNT", new Color(60, 120, 200), new Color(35, 80, 150));
            registerBtn.setPreferredSize(new Dimension(0, 46));
            registerBtn.addActionListener(e -> performAuth("REGISTER"));
            card.add(registerBtn, c);

            add(card, gbc);

            gbc.gridy++;
            JLabel hint = new JLabel("<html><center>No account? Create one — it takes 10 seconds.</center></html>");
            hint.setForeground(new Color(120, 150, 120));
            hint.setFont(new Font("Arial", Font.PLAIN, 12));
            add(hint, gbc);

            passField.addActionListener(e -> performAuth("LOGIN"));
            emailField.addActionListener(e -> performAuth("LOGIN"));
        }

        void setStatus(String msg, Color c) { statusLabel.setText(msg); statusLabel.setForeground(c); }
        void setBusy(boolean b) {
            loginBtn.setEnabled(!b);
            registerBtn.setEnabled(!b);
            setCursor(b ? Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR) : Cursor.getDefaultCursor());
        }
        void reset() {
            passField.setText("");
            setStatus("Enter your account details.", new Color(200, 220, 200));
        }

        @Override protected void paintComponent(Graphics g) {
            drawMenuBackground((Graphics2D) g, this, 0.2f);
        }
    }

    // =====================================================================
    //  MAIN MENU
    // =====================================================================
    class MainMenuScreen extends JPanel {
        private JLabel welcomeLabel;
        private JLabel xpLabel;
        private JProgressBar xpBar;
        private float anim = 0;

        MainMenuScreen() {
            setLayout(new GridBagLayout());
            new Timer(33, e -> { if (isShowing()) { anim += 0.04f; repaint(); } }).start();

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0;
            gbc.insets = new Insets(10, 0, 10, 0);

            if (logoImage != null) {
                add(new JLabel(new ImageIcon(scaleImage(logoImage, 520, 190))), gbc);
            } else {
                JLabel t = new JLabel("NATURE VS UNDEAD");
                t.setFont(new Font("Impact", Font.PLAIN, 52));
                t.setForeground(new Color(190, 255, 110));
                add(t, gbc);
            }

            gbc.gridy++;
            welcomeLabel = new JLabel("");
            welcomeLabel.setFont(new Font("Arial", Font.BOLD, 17));
            welcomeLabel.setForeground(new Color(255, 230, 120));
            add(welcomeLabel, gbc);

            gbc.gridy++;
            xpLabel = new JLabel("");
            xpLabel.setFont(new Font("Arial", Font.BOLD, 13));
            xpLabel.setForeground(new Color(170, 220, 255));
            add(xpLabel, gbc);

            gbc.gridy++;
            xpBar = new JProgressBar(0, 100);
            xpBar.setPreferredSize(new Dimension(340, 14));
            xpBar.setOpaque(false);
            add(xpBar, gbc);

            gbc.gridy++;
            gbc.insets = new Insets(8, 0, 8, 0);
            GradientButton play = mkBtn("PLAY CAMPAIGN", new Color(70, 180, 90), new Color(40, 130, 60));
            play.addActionListener(e -> { levelScreen.refresh(); showScreen("LEVELS"); });
            add(play, gbc);

            gbc.gridy++;
            GradientButton ach = mkBtn("ACHIEVEMENTS", new Color(200, 160, 50), new Color(150, 110, 25));
            ach.addActionListener(e -> { achScreen.refresh(); showScreen("ACH"); });
            add(ach, gbc);

            gbc.gridy++;
            GradientButton set = mkBtn("SETTINGS", new Color(80, 140, 220), new Color(45, 90, 170));
            set.addActionListener(e -> showScreen("SETTINGS"));
            add(set, gbc);

            gbc.gridy++;
            GradientButton out = mkBtn("SIGN OUT", new Color(170, 70, 70), new Color(120, 45, 45));
            out.addActionListener(e -> signOut());
            add(out, gbc);

            refreshUser();
        }

        private GradientButton mkBtn(String text, Color a, Color b) {
            GradientButton btn = new GradientButton(text, a, b);
            btn.setPreferredSize(new Dimension(300, 56));
            return btn;
        }

        void refreshUser() {
            String name = loggedInUser.isEmpty() ? "Guest" : loggedInUser.split("@")[0];
            welcomeLabel.setText("Welcome back, " + name + "  —  Level " + playerLevel + " Commander");
            xpLabel.setText("XP: " + xp + " / " + xpToNext() + "     Coins: " + coins);
            if (xpBar != null) xpBar.setValue((int) Math.min(100, xp * 100 / xpToNext()));
        }

        @Override protected void paintComponent(Graphics g) {
            drawMenuBackground((Graphics2D) g, this, anim);
        }
    }

    // =====================================================================
    //  LEVEL SELECT
    // =====================================================================
    class LevelSelectScreen extends JPanel {
        private JPanel cardsPanel;

        LevelSelectScreen() {
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(40, 60, 40, 60));
            setOpaque(false);

            JLabel title = new JLabel("SELECT LEVEL", SwingConstants.CENTER);
            title.setFont(new Font("Impact", Font.PLAIN, 44));
            title.setForeground(new Color(190, 255, 110));
            title.setBorder(new EmptyBorder(0, 0, 24, 0));
            add(title, BorderLayout.NORTH);

            cardsPanel = new JPanel(new GridLayout(1, 5, 18, 0));
            cardsPanel.setOpaque(false);
            add(cardsPanel, BorderLayout.CENTER);

            GradientButton back = new GradientButton("BACK", new Color(90, 90, 100), new Color(55, 55, 65));
            back.setPreferredSize(new Dimension(200, 50));
            back.addActionListener(e -> showScreen("MENU"));
            JPanel bp = new JPanel(new FlowLayout(FlowLayout.CENTER));
            bp.setOpaque(false);
            bp.setBorder(new EmptyBorder(24, 0, 0, 0));
            bp.add(back);
            add(bp, BorderLayout.SOUTH);

            refresh();
        }

        void refresh() {
            cardsPanel.removeAll();
            for (int i = 0; i < 5; i++) {
                int idx = i;
                boolean unlocked = (i + 1) <= unlockedLevel;
                LevelConfig cfg = LevelConfig.ALL[i];
                JPanel card = new LevelCard(i + 1, cfg.name, cfg.desc, stars[i], unlocked);
                if (unlocked) {
                    card.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    card.addMouseListener(new MouseAdapter() {
                        @Override public void mouseClicked(MouseEvent e) { openLevel(idx); }
                    });
                }
                cardsPanel.add(card);
            }
            cardsPanel.revalidate();
            cardsPanel.repaint();
        }

        @Override protected void paintComponent(Graphics g) {
            drawMenuBackground((Graphics2D) g, this, 0.5f);
        }
    }

    class LevelCard extends RoundedPanel {
        LevelCard(int num, String name, String desc, int starCount, boolean unlocked) {
            super(unlocked ? new Color(22, 34, 22, 235) : new Color(24, 24, 28, 220),
                  unlocked ? new Color(140, 240, 120, 90) : new Color(120, 120, 130, 50), 20);
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(new EmptyBorder(20, 14, 20, 14));

            JLabel numLabel = new JLabel(unlocked ? "LEVEL " + num : "🔒", SwingConstants.CENTER);
            numLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            numLabel.setFont(new Font("Impact", Font.PLAIN, 34));
            numLabel.setForeground(unlocked ? new Color(190, 255, 110) : new Color(130, 130, 140));
            add(numLabel);

            add(Box.createVerticalStrut(8));
            JLabel nameLabel = new JLabel(name, SwingConstants.CENTER);
            nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 15));
            nameLabel.setForeground(unlocked ? Color.WHITE : new Color(140, 140, 150));
            add(nameLabel);

            add(Box.createVerticalStrut(8));
            JLabel descLabel = new JLabel("<html><center>" + desc + "</center></html>", SwingConstants.CENTER);
            descLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            descLabel.setFont(new Font("Arial", Font.PLAIN, 11));
            descLabel.setForeground(new Color(160, 190, 160));
            add(descLabel);

            add(Box.createVerticalGlue());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 3; i++) sb.append(i < starCount ? "★" : "☆");
            JLabel starLabel = new JLabel(sb.toString(), SwingConstants.CENTER);
            starLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            starLabel.setFont(new Font("Arial", Font.PLAIN, 24));
            starLabel.setForeground(starCount > 0 ? new Color(255, 215, 0) : new Color(100, 105, 100));
            add(starLabel);
        }
    }

    // =====================================================================
    //  SETTINGS
    // =====================================================================
    class SettingsScreen extends JPanel {
        SettingsScreen() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(12, 12, 12, 12);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;

            JLabel title = new JLabel("SETTINGS");
            title.setFont(new Font("Impact", Font.PLAIN, 44));
            title.setForeground(new Color(190, 255, 110));
            add(title, gbc);

            gbc.gridy++; gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.WEST;
            add(makeLabel("Music Volume"), gbc);
            gbc.gridx = 1;
            add(makeSlider(), gbc);

            gbc.gridx = 0; gbc.gridy++;
            add(makeLabel("SFX Volume"), gbc);
            gbc.gridx = 1;
            add(makeSlider(), gbc);

            gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
            GradientButton fs = new GradientButton("TOGGLE FULLSCREEN", new Color(80, 140, 220), new Color(45, 90, 170));
            fs.setPreferredSize(new Dimension(320, 50));
            fs.addActionListener(e -> toggleFullScreen());
            add(fs, gbc);

            gbc.gridy++;
            GradientButton reset = new GradientButton("RESET PROGRESS", new Color(170, 70, 70), new Color(120, 45, 45));
            reset.setPreferredSize(new Dimension(320, 50));
            reset.addActionListener(e -> {
                unlockedLevel = 1; stars = new int[5]; totalKills = 0; totalSunCollected = 0;
                playerLevel = 1; xp = 0; coins = 0;
                persistSave(); levelScreen.refresh();
                JOptionPane.showMessageDialog(this, "Progress reset.");
            });
            add(reset, gbc);

            gbc.gridy++;
            GradientButton back = new GradientButton("BACK", new Color(90, 90, 100), new Color(55, 55, 65));
            back.setPreferredSize(new Dimension(320, 50));
            back.addActionListener(e -> showScreen("MENU"));
            add(back, gbc);
        }

        private JLabel makeLabel(String t) {
            JLabel l = new JLabel(t);
            l.setForeground(Color.WHITE);
            l.setFont(new Font("Arial", Font.BOLD, 18));
            return l;
        }
        private JSlider makeSlider() {
            JSlider s = new JSlider(0, 100, 75);
            s.setPreferredSize(new Dimension(220, 40));
            s.setOpaque(false);
            return s;
        }

        @Override protected void paintComponent(Graphics g) {
            drawMenuBackground((Graphics2D) g, this, 0.7f);
        }
    }

    // =====================================================================
    //  ACHIEVEMENTS
    // =====================================================================
    class AchievementsScreen extends JPanel {
        private JPanel list;

        AchievementsScreen() {
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(40, 90, 40, 90));
            setOpaque(false);

            JLabel title = new JLabel("ACHIEVEMENTS", SwingConstants.CENTER);
            title.setFont(new Font("Impact", Font.PLAIN, 44));
            title.setForeground(new Color(190, 255, 110));
            title.setBorder(new EmptyBorder(0, 0, 22, 0));
            add(title, BorderLayout.NORTH);

            list = new JPanel();
            list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
            list.setOpaque(false);
            add(list, BorderLayout.CENTER);

            GradientButton back = new GradientButton("BACK", new Color(90, 90, 100), new Color(55, 55, 65));
            back.setPreferredSize(new Dimension(200, 50));
            back.addActionListener(e -> showScreen("MENU"));
            JPanel bp = new JPanel(new FlowLayout(FlowLayout.CENTER));
            bp.setOpaque(false);
            bp.setBorder(new EmptyBorder(20, 0, 0, 0));
            bp.add(back);
            add(bp, BorderLayout.SOUTH);

            refresh();
        }

        void refresh() {
            list.removeAll();
            String[][] data = {
                {"🩸", "First Blood",      "Defeat your first zombie",       totalKills + " / 1 kills"},
                {"🌻", "Green Economy",    "Collect 500 sun in total",       totalSunCollected + " / 500 sun"},
                {"🧟", "Undead Slayer",    "Defeat 100 zombies in total",    totalKills + " / 100 kills"},
                {"⭐", "Rising Star",      "Earn your first 3-star level",   hasThreeStars() ? "Earned!" : "Not yet"},
                {"🏆", "Garden Guardian",  "Complete all 5 levels",          countComplete() + " / 5 levels"},
                {"💰", "Treasure Hunter",  "Collect 500 coins in total",     coins + " / 500 coins"},
                {"📈", "Seasoned Vet",     "Reach commander level 10",       "Level " + playerLevel + " / 10"}
            };
            for (String[] d : data) list.add(new AchRow(d[0], d[1], d[2], d[3]));
            list.revalidate(); list.repaint();
        }

        private boolean hasThreeStars() { for (int s : stars) if (s == 3) return true; return false; }
        private int countComplete() { int c = 0; for (int s : stars) if (s > 0) c++; return c; }

        @Override protected void paintComponent(Graphics g) {
            drawMenuBackground((Graphics2D) g, this, 0.3f);
        }
    }

    class AchRow extends RoundedPanel {
        AchRow(String icon, String name, String desc, String progress) {
            super(new Color(20, 30, 20, 220), new Color(140, 220, 120, 50), 16);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(14, 18, 14, 18));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 76));

            JLabel l = new JLabel(icon + "  " + name);
            l.setFont(new Font("Arial", Font.BOLD, 18));
            l.setForeground(new Color(255, 230, 130));
            add(l, BorderLayout.WEST);

            JLabel r = new JLabel("<html><center>" + desc + "<br><font size='2' color='#88aa88'>" + progress + "</font></center></html>");
            r.setFont(new Font("Arial", Font.PLAIN, 13));
            r.setForeground(new Color(200, 220, 200));
            r.setHorizontalAlignment(SwingConstants.RIGHT);
            add(r, BorderLayout.EAST);
        }
    }

    // =====================================================================
    //  SHARED UI HELPERS
    // =====================================================================
    void drawMenuBackground(Graphics2D g2, JComponent c, float anim) {
        frameCount++;
        int W = c.getWidth(), H = c.getHeight();
        if (W <= 0 || H <= 0) return;
        if (menuBgCache == null || menuBgW != W || menuBgH != H) buildMenuBg(W, H);
        g2.drawImage(menuBgCache, 0, 0, null);

        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.18f));
        for (int i = 0; i < 14; i++) {
            double a = anim * 0.7 + i * 1.3;
            int x = (int) ((i * 97 + Math.sin(a) * 40 + anim * 14) % Math.max(W, 1));
            int y = (int) ((i * 173 + Math.cos(a * 0.8) * 30) % Math.max(H, 1));
            g2.setColor(i % 3 == 0 ? new Color(255, 230, 120) : new Color(140, 230, 110));
            g2.fillOval(x, y, 5 + (i % 4) * 2, 5 + (i % 4) * 2);
        }
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }

    /** Background + dark tint + vignette baked once per window size. */
    private void buildMenuBg(int W, int H) {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        if (backgroundImage != null) {
            g2.drawImage(backgroundImage, 0, 0, W, H, null);
            g2.setColor(new Color(0, 0, 0, 110));
            g2.fillRect(0, 0, W, H);
        } else {
            g2.setPaint(new GradientPaint(0, 0, new Color(16, 34, 18), W, H, new Color(8, 16, 10)));
            g2.fillRect(0, 0, W, H);
        }
        RadialGradientPaint vg = new RadialGradientPaint(new Point(W / 2, H / 2), Math.max(W, H) * 0.75f,
                new float[]{0f, 1f}, new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 150)});
        g2.setPaint(vg);
        g2.fillRect(0, 0, W, H);
        g2.dispose();
        menuBgCache = img; menuBgW = W; menuBgH = H;
    }

    static BufferedImage scaleImage(BufferedImage src, int maxW, int maxH) {
        double s = Math.min((double) maxW / src.getWidth(), (double) maxH / src.getHeight());
        int w = Math.max(1, (int) (src.getWidth() * s)), h = Math.max(1, (int) (src.getHeight() * s));
        return scaleHQ(src, w, h);
    }

    class RoundedPanel extends JPanel {
        private final Color fill, border; private final int radius;
        RoundedPanel(Color fill, Color border, int radius) {
            this.fill = fill; this.border = border; this.radius = radius;
            setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(border);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, radius, radius);
            super.paintComponent(g);
        }
    }

    class RoundedTextField extends JTextField {
        RoundedTextField() {
            setOpaque(false);
            setFont(new Font("Arial", Font.PLAIN, 16));
            setForeground(Color.WHITE);
            setCaretColor(new Color(150, 255, 150));
            setBorder(new EmptyBorder(9, 14, 9, 14));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(30, 42, 30));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.setColor(hasFocus() ? new Color(140, 230, 130) : new Color(90, 140, 90));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    class GradientButton extends JButton {
        private final Color top, bottom;
        private boolean hover, press;
        GradientButton(String text, Color top, Color bottom) {
            super(text);
            this.top = top; this.bottom = bottom;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Arial", Font.BOLD, 17));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e)  { hover = false; press = false; repaint(); }
                @Override public void mousePressed(MouseEvent e) { press = true; repaint(); }
                @Override public void mouseReleased(MouseEvent e){ press = false; repaint(); }
            });
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(getFont());
            int y = press ? 2 : 0, h = getHeight() - (press ? 4 : 2);
            Color t = hover ? top.brighter() : top;
            Color b = hover ? bottom.brighter() : bottom;
            if (!isEnabled()) { t = t.darker(); b = b.darker(); }
            g2.setPaint(new GradientPaint(0, y, t, 0, y + h, b));
            g2.fillRoundRect(0, y, getWidth(), h, 14, 14);
            g2.setColor(new Color(255, 255, 255, 40));
            g2.fillRoundRect(0, y, getWidth(), h / 2, 14, 14);
            g2.setColor(new Color(0, 0, 0, 90));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(1, y + 1, getWidth() - 2, h - 2, 13, 13);
            FontMetrics fm = g2.getFontMetrics();
            int tx = (getWidth() - fm.stringWidth(getText())) / 2;
            int ty = y + (h - fm.getHeight()) / 2 + fm.getAscent();
            g2.setColor(new Color(0, 0, 0, 130));
            g2.drawString(getText(), tx + 1, ty + 1);
            g2.setColor(getForeground());
            g2.drawString(getText(), tx, ty);
            g2.dispose();
        }
    }

    // =====================================================================
    //  LEVEL CONFIG
    // =====================================================================
    static class LevelConfig {
        String name, desc;
        int zombieCount; double spawnInterval; int zombieHp; double speed;
        double coneChance, bucketChance; int startSun; double skySunInterval;

        LevelConfig(String name, String desc, int count, double interval, int hp, double speed,
                    double cone, double bucket, int sun, double skySun) {
            this.name = name; this.desc = desc; this.zombieCount = count;
            this.spawnInterval = interval; this.zombieHp = hp; this.speed = speed;
            this.coneChance = cone; this.bucketChance = bucket;
            this.startSun = sun; this.skySunInterval = skySun;
        }

        static final LevelConfig[] ALL = {
            new LevelConfig("First Sprout",  "A gentle introduction.<br>Learn the basics.", 8,  6.0, 180, 0.35, 0,    0,    100, 8.0),
            new LevelConfig("Growing Pains", "Coneheads join the horde.",                     14, 5.0, 200, 0.38, 0.25, 0,    100, 8.5),
            new LevelConfig("Night Shift",   "The dead walk faster now.",                     20, 4.5, 230, 0.42, 0.35, 0.10, 100, 9.0),
            new LevelConfig("Bucket Brigade","Metal heads incoming.",                         26, 4.0, 250, 0.45, 0.40, 0.20, 125, 9.5),
            new LevelConfig("The Last Lawn", "Everything at once.<br>Hold the line!",         34, 3.4, 280, 0.48, 0.40, 0.28, 150, 10.0)
        };
    }

    // =====================================================================
    //  GAME PANEL
    // =====================================================================
    enum SeedType {
        SUNFLOWER(50), PEASHOOTER(100), WALLNUT(50), SNOWPEA(175), REPEATER(200), CHERRYBOMB(150);
        final int cost; SeedType(int c) { cost = c; }
    }
    enum ZType  { NORMAL(180, 0.35), CONE(450, 0.35), BUCKET(900, 0.30);
        final int hp; final double spd; ZType(int h, double s) { hp = h; spd = s; } }
    enum GState { PLACING, RUNNING, WON, LOST }
    enum CollectType { COIN10, COIN25, GEM50, SUN50 }

    class GamePanel extends JPanel {
        static final int ROWS = 5, COLS = 9;
        static final int CELL_W = 96, CELL_H = 100;
        static final int GX = 240, GY = 190;

        private final LevelConfig cfg;
        private final int levelIdx;
        private final GameCallback callback;
        private final BufferedImage imgPea, imgSun, imgNut, imgSnow, imgCherry, imgRepeater, imgZombie, imgSunDrop, imgPeaBall;

        private final Random rand = new Random();
        private GState state = GState.RUNNING;
        private long elapsed = 0;
        private double spawnTimer = 2500;
        private double skySunTimer = 4000;
        private int sun;
        private long sunCollectedRun = 0;
        private int spawned = 0, killed = 0;
        private SeedType selected = null;
        private boolean finalWaveShown = false;
        private int hoverX = -1, hoverY = -1;

        private final Plant[][] grid = new Plant[ROWS][COLS];
        private final List<Zombie> zombies = new ArrayList<Zombie>();
        private final List<Pea> peas = new ArrayList<Pea>();
        private final List<SunDrop> suns = new ArrayList<SunDrop>();
        private final List<Collectible> collectibles = new ArrayList<Collectible>();
        private final List<Particle> particles = new ArrayList<Particle>();
        private final List<Shockwave> shockwaves = new ArrayList<Shockwave>();
        private final boolean[] mowerAlive = new boolean[ROWS];
        private final double[] mowerX = new double[ROWS];
        private final boolean[] mowerActive = new boolean[ROWS];
        private boolean anyMowerLost = false;

        private final List<Rectangle> seedCards = new ArrayList<Rectangle>();
        private final Rectangle menuBtn = new Rectangle(1130, 22, 120, 40);

        private final Timer gameTimer;
        private boolean ended, reported, endPainted;
        private BufferedImage sceneCache;
        private int sceneW, sceneH;
        private final Map<Long, BufferedImage> fitCache = new HashMap<>();
        private final Map<BufferedImage, BufferedImage> silCache = new HashMap<>();

        /** White copy of a sprite (same alpha) used for the damage flash. Built once per sprite. */
        private BufferedImage silhouette(BufferedImage f) {
            BufferedImage sil = silCache.get(f);
            if (sil == null) {
                int w = f.getWidth(), h = f.getHeight();
                sil = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                        sil.setRGB(x, y, (f.getRGB(x, y) & 0xFF000000) | 0x00FFFFFF);
                silCache.put(f, sil);
            }
            return sil;
        }

        GamePanel(LevelConfig cfg, int levelIdx, GameCallback cb,
                  BufferedImage pea, BufferedImage sunflower, BufferedImage walnut,
                  BufferedImage snowpea, BufferedImage cherry, BufferedImage repeater,
                  BufferedImage zombie, BufferedImage sundrop, BufferedImage peaball) {
            this.cfg = cfg; this.levelIdx = levelIdx; this.callback = cb;
            this.imgPea = pea; this.imgSun = sunflower; this.imgNut = walnut;
            this.imgSnow = snowpea; this.imgCherry = cherry; this.imgRepeater = repeater;
            this.imgZombie = zombie; this.imgSunDrop = sundrop; this.imgPeaBall = peaball;

            this.sun = cfg.startSun;
            for (int r = 0; r < ROWS; r++) { mowerAlive[r] = true; mowerX[r] = GX - 46; }

            setPreferredSize(new Dimension(1280, 800));
            setFocusable(true);

            MouseAdapter mouse = new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) { handleClick(e.getX(), e.getY()); }
                @Override public void mouseExited(MouseEvent e) { hoverX = -1; hoverY = -1; }
            };
            addMouseListener(mouse);
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseMoved(MouseEvent e) { hoverX = e.getX(); hoverY = e.getY(); }
                @Override public void mouseDragged(MouseEvent e) { hoverX = e.getX(); hoverY = e.getY(); }
            });

            addKeyListener(new KeyAdapter() {
                @Override public void keyPressed(KeyEvent e) {
                    int code = e.getKeyCode();
                    if (code == KeyEvent.VK_ESCAPE) {
                        if (state == GState.RUNNING && selected != null) { selected = null; repaint(); }
                        else endGame();
                        return;
                    }
                    int n = code - KeyEvent.VK_1;
                    if (n >= 0 && n < SeedType.values().length) {
                        selected = (selected == SeedType.values()[n]) ? null : SeedType.values()[n];
                        repaint();
                    }
                }
            });

            gameTimer = new Timer(16, e -> tick());
            gameTimer.start();
        }

        // ---------- gameplay ----------
        private void tick() {
            if (state != GState.RUNNING) {
                if (!endPainted) { endPainted = true; repaint(); } else gameTimer.stop();
                return;
            }
            elapsed += 16;

            if (spawned < cfg.zombieCount) {
                spawnTimer -= 16;
                if (spawnTimer <= 0) {
                    spawnZombie();
                    spawned++;
                    spawnTimer = cfg.spawnInterval * 1000 * (0.75 + rand.nextDouble() * 0.5);
                }
            } else if (!finalWaveShown) {
                finalWaveShown = true;
            }

            skySunTimer -= 16;
            if (skySunTimer <= 0) {
                suns.add(new SunDrop(200 + rand.nextInt(900), -30, 140 + rand.nextInt(380), true));
                skySunTimer = cfg.skySunInterval * 1000;
            }

            // plants act
            for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
                Plant p = grid[r][c];
                if (p == null) continue;

                if (p.type == SeedType.CHERRYBOMB) {
                    if (elapsed - p.plantedAt > 1300) {
                        explode(r, c);
                        grid[r][c] = null;
                    }
                    continue;
                }

                if (p.type == SeedType.SUNFLOWER) {
                    if (elapsed - p.lastAction > 7000) {
                        p.lastAction = elapsed;
                        suns.add(new SunDrop(cellX(c) + CELL_W/2, cellY(r) + 10, cellY(r) + 14, false));
                    }
                } else if (p.type == SeedType.PEASHOOTER || p.type == SeedType.SNOWPEA || p.type == SeedType.REPEATER) {
                    if (elapsed - p.lastAction > 1500 && zombieAhead(r, c)) {
                        p.lastAction = elapsed;
                        boolean ice = p.type == SeedType.SNOWPEA;
                        peas.add(new Pea(cellX(c) + CELL_W - 14, cellY(r) + CELL_H/2 - 18, r, ice ? 40 : 55, ice));
                        if (p.type == SeedType.REPEATER) p.pendingSecond = true;
                    }
                    if (p.pendingSecond && elapsed - p.lastAction > 220) {
                        p.pendingSecond = false;
                        peas.add(new Pea(cellX(c) + CELL_W - 14, cellY(r) + CELL_H/2 - 18, r, 55, false));
                    }
                }
            }

            // peas
            for (int i = peas.size() - 1; i >= 0; i--) {
                Pea p = peas.get(i);
                p.x += 7.5;
                boolean hit = false;
                for (Zombie z : zombies) {
                    if (!z.dying && z.row == p.row && p.x > z.x - 8 && p.x < z.x + 46) {
                        z.hp -= p.dmg;
                        z.hitAt = elapsed;
                        if (p.ice) z.slowUntil = elapsed + 3000;
                        splatter(p.x, p.y, p.ice);
                        hit = true;
                        break;
                    }
                }
                if (hit || p.x > getWidth() + 20) peas.remove(i);
            }

            // zombies
            for (int i = zombies.size() - 1; i >= 0; i--) {
                Zombie z = zombies.get(i);
                if (z.dying) {
                    if (elapsed - z.dyingAt > 1000) zombies.remove(i);
                    continue;
                }
                if (z.hp <= 0) {
                    z.dying = true;
                    z.dyingAt = elapsed;
                    z.eating = false;
                    splatter(z.x + 20, cellY(z.row) + CELL_H/2, false);
                    burst(z.x + 10, cellY(z.row) + CELL_H - 16, new Color(150, 150, 135));
                    maybeDrop(z);
                    killed++;
                    callback.onKill();
                    continue;
                }
                int col = (int)((z.x - GX) / CELL_W);
                Plant target = (col >= 0 && col < COLS) ? grid[z.row][col] : null;
                boolean atPlant = target != null && z.x < cellX(col) + CELL_W - 8;
                z.eating = atPlant;
                z.animT += (elapsed < z.slowUntil) ? 7 : 16;
                if (atPlant) {
                    if (elapsed - z.lastBite > 500) {
                        z.lastBite = elapsed;
                        target.hp -= 20;
                        if (target.hp <= 0) grid[z.row][col] = null;
                    }
                } else {
                    double slowMul = (elapsed < z.slowUntil) ? 0.45 : 1.0;
                    z.x -= z.type.spd * (cfg.speed / 0.35) * slowMul;
                }
                if (z.x < GX - 30) {
                    if (mowerAlive[z.row] && !mowerActive[z.row]) {
                        mowerActive[z.row] = true;
                        anyMowerLost = true;
                    } else if (!mowerAlive[z.row]) {
                        state = GState.LOST;
                    }
                }
            }

            // lawn mowers
            for (int r = 0; r < ROWS; r++) {
                if (mowerActive[r]) {
                    mowerX[r] += 9;
                    for (Zombie z : zombies) {
                        if (z.row == r && z.x < mowerX[r] + 40) z.hp = 0;
                    }
                    if (mowerX[r] > getWidth() + 60) { mowerActive[r] = false; mowerAlive[r] = false; }
                }
            }

            // suns
            for (int i = suns.size() - 1; i >= 0; i--) {
                SunDrop s = suns.get(i);
                if (s.y < s.targetY) s.y += 1.6;
                else if (s.landedAt == 0) s.landedAt = elapsed;
                if (s.landedAt != 0 && elapsed - s.landedAt > 9000) suns.remove(i);
            }

            // collectibles
            for (int i = collectibles.size() - 1; i >= 0; i--) {
                Collectible k = collectibles.get(i);
                if (k.y < k.targetY) k.y += 2.2;
                else if (k.landedAt == 0) k.landedAt = elapsed;
                if (k.landedAt != 0 && elapsed - k.landedAt > 8000) collectibles.remove(i);
            }

            // shockwaves
            for (int i = shockwaves.size() - 1; i >= 0; i--) {
                Shockwave s = shockwaves.get(i);
                s.r += 9; s.life--;
                if (s.life <= 0) shockwaves.remove(i);
            }

            // particles
            for (int i = particles.size() - 1; i >= 0; i--) {
                Particle p = particles.get(i);
                p.x += p.vx; p.y += p.vy; p.vy += 0.15; p.life--;
                if (p.life <= 0) particles.remove(i);
            }

            while (particles.size() > 500) particles.remove(0);

            if (state == GState.RUNNING && spawned >= cfg.zombieCount && zombies.isEmpty()) {
                state = GState.WON;
            }
            repaint();
        }

        private void spawnZombie() {
            int row = rand.nextInt(ROWS);
            ZType type;
            double roll = rand.nextDouble();
            if (roll < cfg.bucketChance) type = ZType.BUCKET;
            else if (roll < cfg.bucketChance + cfg.coneChance) type = ZType.CONE;
            else type = ZType.NORMAL;
            double hpScale = (double) cfg.zombieHp / 180.0;
            zombies.add(new Zombie(row, getWidth() + 30, type, (int)(type.hp * hpScale)));
        }

        private boolean zombieAhead(int row, int col) {
            for (Zombie z : zombies)
                if (!z.dying && z.row == row && z.x > cellX(col)) return true;
            return false;
        }

        private void explode(int r, int c) {
            int cx = cellX(c) + CELL_W / 2, cy = cellY(r) + CELL_H / 2;
            shockwaves.add(new Shockwave(cx, cy, 10));
            for (int i = 0; i < 40; i++) {
                double a = rand.nextDouble() * Math.PI * 2;
                double sp = 2 + rand.nextDouble() * 6;
                particles.add(new Particle(cx, cy, Math.cos(a) * sp, Math.sin(a) * sp - 2,
                        40 + rand.nextInt(25),
                        rand.nextBoolean() ? new Color(255, 120, 40) : new Color(255, 200, 60)));
            }
            for (Zombie z : zombies) {
                if (Math.abs(z.row - r) <= 1
                        && z.x > cellX(Math.max(0, c - 1)) - 20
                        && z.x < cellX(Math.min(COLS - 1, c + 1)) + CELL_W + 20) {
                    z.hp = 0;
                }
            }
        }

        private void maybeDrop(Zombie z) {
            double roll = rand.nextDouble();
            int y = cellY(z.row) + CELL_H / 2;
            if (roll < 0.06) {
                collectibles.add(new Collectible(CollectType.SUN50, z.x, y, y + 10));
            } else if (roll < 0.10) {
                collectibles.add(new Collectible(CollectType.GEM50, z.x, y, y + 10));
            } else if (roll < 0.22) {
                collectibles.add(new Collectible(CollectType.COIN25, z.x, y, y + 10));
            } else if (roll < 0.42) {
                collectibles.add(new Collectible(CollectType.COIN10, z.x, y, y + 10));
            }
        }

        private void splatter(double x, double y, boolean ice) {
            Color c = ice ? new Color(140, 210, 255) : new Color(120, 200, 60);
            for (int i = 0; i < 6; i++)
                particles.add(new Particle(x, y, (rand.nextDouble() - 0.5) * 4, -rand.nextDouble() * 3, 25, c));
        }

        private int cellX(int c) { return GX + c * CELL_W; }
        private int cellY(int r) { return GY + r * CELL_H; }

        private void handleClick(int mx, int my) {
            if (state == GState.WON || state == GState.LOST) {
                int cx = getWidth() / 2, cy = getHeight() / 2;
                if (inRect(mx, my, cx - 220, cy + 90, 140, 52)) {
                    reportResult();
                    openLevel(levelIdx);
                } else if (state == GState.WON && inRect(mx, my, cx - 70, cy + 90, 140, 52)) {
                    reportResult();
                    if (levelIdx < 4) openLevel(levelIdx + 1);
                } else if (inRect(mx, my, cx + 80, cy + 90, 140, 52)) {
                    endGame();
                }
                return;
            }
            if (menuBtn.contains(mx, my)) { endGame(); return; }

            // collectibles first (they're small and precious)
            for (int i = collectibles.size() - 1; i >= 0; i--) {
                Collectible k = collectibles.get(i);
                if (Math.hypot(mx - k.x, my - k.y) < 30) {
                    collectibles.remove(i);
                    collect(k);
                    return;
                }
            }

            // suns
            for (int i = suns.size() - 1; i >= 0; i--) {
                SunDrop s = suns.get(i);
                if (Math.hypot(mx - s.x, my - s.y) < 34) {
                    suns.remove(i);
                    sun += 25;
                    sunCollectedRun += 25;
                    burst(s.x, s.y, new Color(255, 220, 60));
                    return;
                }
            }

            // seed cards
            for (int i = 0; i < seedCards.size(); i++) {
                if (seedCards.get(i).contains(mx, my)) {
                    selected = (selected == SeedType.values()[i]) ? null : SeedType.values()[i];
                    return;
                }
            }

            // grid placement
            int col = (mx - GX) / CELL_W;
            int row = (my - GY) / CELL_H;
            if (mx >= GX && my >= GY && col >= 0 && col < COLS && row >= 0 && row < ROWS && selected != null) {
                if (grid[row][col] != null) return;
                if (sun < selected.cost) { flashNotEnough(); return; }
                sun -= selected.cost;
                Plant p = new Plant(row, col, selected);
                grid[row][col] = p;
                for (int k = 0; k < 10; k++)
                    particles.add(new Particle(cellX(col) + CELL_W/2, cellY(row) + CELL_H/2,
                            (rand.nextDouble()-0.5)*3, -rand.nextDouble()*2.5, 22, new Color(140, 240, 120)));
                if (selected == SeedType.PEASHOOTER || selected == SeedType.SNOWPEA
                        || selected == SeedType.REPEATER || selected == SeedType.CHERRYBOMB) {
                    selected = null;
                }
            }
        }

        private void collect(Collectible k) {
            switch (k.type) {
                case COIN10: callback.onCollect(10, 0); burst(k.x, k.y, new Color(255, 215, 60)); break;
                case COIN25: callback.onCollect(25, 0); burst(k.x, k.y, new Color(255, 215, 60)); break;
                case GEM50:  callback.onCollect(50, 0); burst(k.x, k.y, new Color(160, 120, 255)); break;
                case SUN50:  callback.onCollect(0, 50); sun += 50; sunCollectedRun += 50;
                             burst(k.x, k.y, new Color(255, 240, 140)); break;
            }
        }

        private void burst(double x, double y, Color c) {
            for (int k = 0; k < 8; k++)
                particles.add(new Particle(x, y, (rand.nextDouble()-0.5)*3, -rand.nextDouble()*3, 20, c));
        }

        private void flashNotEnough() {
            for (int k = 0; k < 6; k++)
                particles.add(new Particle(90, 40, (rand.nextDouble()-0.5)*2, -rand.nextDouble()*2, 18, Color.RED));
        }

        private boolean inRect(int x, int y, int rx, int ry, int rw, int rh) {
            return x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
        }

        private void reportResult() {
            if (reported || state != GState.WON) return;
            reported = true;
            int starCount = anyMowerLost ? (mowersLostCount() == 1 ? 2 : 1) : 3;
            callback.onLevelComplete(levelIdx, starCount, killed, sunCollectedRun);
        }

        void shutdown() { gameTimer.stop(); }

        private void endGame() {
            if (ended) return;
            ended = true;
            reportResult();
            shutdown();
            callback.onGameExit();
        }

        private int mowersLostCount() { int n = 0; for (boolean b : mowerAlive) if (!b) n++; return n; }

        // ---------- painting ----------
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            frameCount++;
            int W = getWidth(), H = getHeight();

            if (sceneCache == null || sceneW != W || sceneH != H) buildScene(W, H);
            g2.drawImage(sceneCache, 0, 0, null);
            drawSkyDynamic(g2, W);

            // mowers
            for (int r = 0; r < ROWS; r++) drawMower(g2, r);

            // hover cell highlight
            if (selected != null && hoverX >= GX && hoverY >= GY) {
                int col = (hoverX - GX) / CELL_W;
                int row = (hoverY - GY) / CELL_H;
                if (col >= 0 && col < COLS && row >= 0 && row < ROWS) {
                    boolean ok = grid[row][col] == null && sun >= selected.cost;
                    g2.setColor(ok ? new Color(255, 255, 255, 60) : new Color(255, 80, 80, 60));
                    g2.fillRoundRect(cellX(col) + 3, cellY(row) + 3, CELL_W - 6, CELL_H - 6, 12, 12);
                    if (ok) {
                        g2.setColor(new Color(255, 255, 255, 120));
                        g2.setStroke(new BasicStroke(2f));
                        g2.drawRoundRect(cellX(col) + 3, cellY(row) + 3, CELL_W - 6, CELL_H - 6, 12, 12);
                    }
                }
            }

            // plants
            for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
                Plant p = grid[r][c];
                if (p != null) drawPlant(g2, p);
            }

            for (Zombie z : zombies) drawZombie(g2, z);

            // peas
            for (Pea p : peas) {
                if (imgPeaBall != null) {
                    int d = p.ice ? 26 : 24;
                    BufferedImage pb = fitted(imgPeaBall, d, d);
                    g2.drawImage(pb, (int) p.x - pb.getWidth() / 2, (int) p.y - pb.getHeight() / 2, null);
                    if (p.ice) {
                        g2.setColor(new Color(160, 220, 255, 110));
                        g2.fillOval((int) p.x - 14, (int) p.y - 14, 28, 28);
                    }
                } else if (p.ice) {
                    g2.setColor(new Color(160, 220, 255, 130));
                    g2.fillOval((int) p.x - 11, (int) p.y - 11, 22, 22);
                    g2.setColor(new Color(200, 240, 255));
                    g2.fillOval((int) p.x - 7, (int) p.y - 7, 14, 14);
                    g2.setColor(Color.WHITE);
                    g2.fillOval((int) p.x - 3, (int) p.y - 3, 5, 5);
                } else {
                    g2.setColor(new Color(120, 220, 60, 120));
                    g2.fillOval((int) p.x - 11, (int) p.y - 11, 22, 22);
                    g2.setColor(new Color(140, 230, 80));
                    g2.fillOval((int) p.x - 7, (int) p.y - 7, 14, 14);
                    g2.setColor(new Color(220, 255, 170));
                    g2.fillOval((int) p.x - 3, (int) p.y - 4, 6, 6);
                }
            }

            // suns
            for (SunDrop s : suns) drawSun(g2, s);

            // collectibles
            for (Collectible k : collectibles) drawCollectible(g2, k);

            // shockwaves
            for (Shockwave s : shockwaves) {
                float a = Math.max(0, s.life / 30f);
                g2.setColor(new Color(255, 180, 60, (int)(180 * a)));
                g2.setStroke(new BasicStroke(6f * a + 2f));
                g2.drawOval(s.x - s.r, s.y - s.r, s.r * 2, s.r * 2);
            }

            // particles
            for (Particle p : particles) {
                g2.setColor(new Color(p.c.getRed(), p.c.getGreen(), p.c.getBlue(), Math.max(0, Math.min(255, p.life * 10))));
                g2.fillOval((int) p.x, (int) p.y, 5, 5);
            }

            drawHUD(g2, W);
            drawSeedBar(g2);

            if (finalWaveShown && state == GState.RUNNING) {
                g2.setFont(new Font("Impact", Font.PLAIN, 40));
                g2.setColor(new Color(255, 120, 80));
                String fw = "FINAL WAVE!";
                g2.drawString(fw, W / 2 - g2.getFontMetrics().stringWidth(fw) / 2, GY - 24);
            }

            if (state == GState.WON)  drawEndOverlay(g2, true);
            if (state == GState.LOST) drawEndOverlay(g2, false);
        }

        // ===== scenery =====
        /** Sky, sun, trees, lawn, house, soil, texture — drawn ONCE per window size. */
        private void buildScene(int W, int H) {
            BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(98, 172, 64));
            g.fillRect(0, 0, W, H);
            drawSkyStatic(g, W);
            drawLawn(g, W, H);
            g.dispose();
            sceneCache = img; sceneW = W; sceneH = H;
        }

        private void drawSkyStatic(Graphics2D g2, int W) {
            g2.setPaint(new GradientPaint(0, 0, new Color(96, 155, 205),
                    0, GY * 0.6f, new Color(150, 190, 200)));
            g2.fillRect(0, 0, W, (int)(GY * 0.6f));
            g2.setPaint(new GradientPaint(0, GY * 0.6f, new Color(150, 190, 200),
                    0, GY, new Color(178, 208, 148)));
            g2.fillRect(0, (int)(GY * 0.6f), W, GY - (int)(GY * 0.6f));

            int sx = W - 150, sy = 55;
            RadialGradientPaint sunGlow = new RadialGradientPaint(
                    new Point(sx + 20, sy + 20), 95,
                    new float[]{0f, 0.45f, 1f},
                    new Color[]{new Color(255, 240, 150, 150), new Color(255, 225, 100, 60), new Color(255, 225, 100, 0)});
            g2.setPaint(sunGlow);
            g2.fillOval(sx - 75, sy - 75, 190, 190);
            g2.setColor(new Color(255, 235, 140));
            g2.fillOval(sx - 20, sy - 20, 80, 80);
            g2.setColor(new Color(255, 248, 200));
            g2.fillOval(sx - 10, sy - 10, 44, 44);

            g2.setColor(new Color(70, 110, 62, 130));
            for (int x = -20; x < W + 40; x += 52) {
                int h = 26 + ((x * 7919) % 22 + 22) % 22;
                g2.fillOval(x, GY - h, 58, h + 14);
            }
            g2.setColor(new Color(52, 88, 48, 160));
            for (int x = 6; x < W + 40; x += 64) {
                int h = 20 + ((x * 104729) % 18 + 18) % 18;
                g2.fillOval(x, GY - h + 6, 46, h + 10);
            }
        }

        private void drawSkyDynamic(Graphics2D g2, int W) {
            g2.setColor(new Color(255, 255, 255, 120));
            for (int i = 0; i < 3; i++) {
                int cx = (int)((i * 460 + elapsed * 0.010) % (W + 360)) - 180;
                int cy = 30 + i * 30;
                cloud(g2, cx, cy, 1.35f);
            }
            g2.setColor(new Color(255, 255, 255, 180));
            for (int i = 0; i < 4; i++) {
                int cx = (int)((i * 340 + elapsed * 0.020) % (W + 320)) - 160;
                int cy = 42 + i * 24;
                cloud(g2, cx, cy, 1.0f);
            }
            g2.setColor(new Color(40, 50, 45, 160));
            g2.setStroke(new BasicStroke(1.6f));
            for (int i = 0; i < 3; i++) {
                int bx = (int)((i * 500 + elapsed * 0.05) % (W + 100)) - 50;
                int by = 46 + i * 22 + (int)(Math.sin(elapsed / 300.0 + i) * 6);
                int flap = (int)(Math.sin(elapsed / 90.0 + i * 2) * 5);
                g2.drawArc(bx - 9, by - 4 + flap, 9, 8, 0, 180);
                g2.drawArc(bx, by - 4 + flap, 9, 8, 0, 180);
            }
        }

        private void cloud(Graphics2D g2, int x, int y, float s) {
            g2.fillOval(x, y, (int)(110 * s), (int)(30 * s));
            g2.fillOval(x + (int)(26 * s), y - (int)(12 * s), (int)(70 * s), (int)(30 * s));
            g2.fillOval(x + (int)(52 * s), y, (int)(80 * s), (int)(26 * s));
        }

        private void drawLawn(Graphics2D g2, int W, int H) {
            // soil below lawn
            g2.setPaint(new GradientPaint(0, GY + ROWS * CELL_H, new Color(96, 66, 38), 0, H, new Color(62, 42, 24)));
            g2.fillRect(0, GY + ROWS * CELL_H, W, H - (GY + ROWS * CELL_H));
            g2.setColor(new Color(50, 34, 18));
            for (int i = 0; i < 26; i++) {
                int x = (i * 97) % W;
                int y = GY + ROWS * CELL_H + 12 + (i * 31) % Math.max(1, H - (GY + ROWS * CELL_H) - 20);
                g2.fillOval(x, y, 10 + (i % 3) * 5, 5);
            }

            // lawn cells: checker + row sheen + texture + detail
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    Color base = (r % 2 == 0) ? new Color(98, 172, 64) : new Color(86, 156, 56);
                    if ((r + c) % 2 == 1) base = base.darker();
                    g2.setColor(base);
                    g2.fillRect(cellX(c), cellY(r), CELL_W, CELL_H);

                    g2.setColor(new Color(255, 255, 220, 16));
                    g2.fillRect(cellX(c), cellY(r), CELL_W, CELL_H / 3);

                    // grass strokes
                    g2.setColor(new Color(255, 255, 255, 10));
                    int seed = r * 31 + c * 17;
                    for (int k = 0; k < 5; k++) {
                        int gx = cellX(c) + (seed * (k + 3) * 13) % CELL_W;
                        int gy = cellY(r) + (seed * (k + 5) * 7) % CELL_H;
                        g2.drawLine(gx, gy, gx + 4, gy - 6);
                    }
                    // occasional flower
                    if ((seed % 11) == 0) {
                        int fx = cellX(c) + 14 + (seed * 7) % (CELL_W - 28);
                        int fy = cellY(r) + 16 + (seed * 11) % (CELL_H - 32);
                        g2.setColor(new Color(255, 200, 220));
                        for (int a = 0; a < 5; a++) {
                            double ang = a * Math.PI * 2 / 5;
                            g2.fillOval((int)(fx + Math.cos(ang) * 5) - 3, (int)(fy + Math.sin(ang) * 5) - 3, 6, 6);
                        }
                        g2.setColor(new Color(255, 220, 80));
                        g2.fillOval(fx - 3, fy - 3, 6, 6);
                    }
                }
                g2.setColor(new Color(58, 108, 40));
                g2.drawLine(GX, cellY(r), GX + COLS * CELL_W, cellY(r));
            }
            g2.setColor(new Color(255, 255, 255, 16));
            for (int c = 0; c <= COLS; c++) g2.drawLine(cellX(c), GY, cellX(c), GY + ROWS * CELL_H);
            g2.setColor(new Color(255, 255, 255, 24));
            g2.drawLine(GX, GY + ROWS * CELL_H, GX + COLS * CELL_W, GY + ROWS * CELL_H);

            // texture.png overlay — subtle grain across the lawn
            if (textureImage != null) {
                Shape oldClip = g2.getClip();
                g2.setClip(GX, GY, COLS * CELL_W, ROWS * CELL_H);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.14f));
                int tw = Math.max(1, textureImage.getWidth()), th = Math.max(1, textureImage.getHeight());
                for (int x = GX; x < GX + COLS * CELL_W; x += tw) {
                    for (int y = GY; y < GY + ROWS * CELL_H; y += th) {
                        g2.drawImage(textureImage, x, y, null);
                    }
                }
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                g2.setClip(oldClip);
            }

            // soft shadow under plant rows for depth
            g2.setPaint(new GradientPaint(0, GY, new Color(0, 0, 0, 50), 0, GY + 40, new Color(0, 0, 0, 0)));
            g2.fillRect(GX, GY, COLS * CELL_W, 40);

            // house strip
            g2.setPaint(new GradientPaint(0, GY, new Color(92, 68, 48), 0, GY + ROWS * CELL_H, new Color(56, 40, 28)));
            g2.fillRect(0, GY, GX - 60, ROWS * CELL_H);
            g2.setColor(new Color(44, 32, 22));
            g2.fillRect(GX - 60, GY, 20, ROWS * CELL_H);
            g2.setColor(new Color(255, 255, 255, 14));
            for (int r = 0; r < ROWS; r++) g2.drawLine(10, cellY(r) + 12, GX - 70, cellY(r) + 12);

            // house wall details: roof edge, window, door
            g2.setPaint(new GradientPaint(0, GY, new Color(120, 60, 40), 0, GY + 34, new Color(88, 42, 28)));
            g2.fillPolygon(new int[]{0, GX - 40, GX - 60, 0}, new int[]{GY, GY, GY + 34, GY + 34}, 4);
            g2.setColor(new Color(255, 235, 160, 90));
            g2.fillRoundRect(26, GY + 140, 74, 92, 8, 8);
            g2.setColor(new Color(60, 42, 30));
            g2.drawRoundRect(26, GY + 140, 74, 92, 8, 8);
            g2.drawLine(63, GY + 140, 63, GY + 232);
            g2.drawLine(26, GY + 186, 100, GY + 186);
            g2.setPaint(new GradientPaint(0, GY + 300, new Color(110, 72, 44), 0, GY + ROWS * CELL_H, new Color(80, 52, 30)));
            g2.fillRoundRect(40, GY + 300, 84, ROWS * CELL_H - 320, 10, 10);
            g2.setColor(new Color(50, 32, 18));
            g2.drawRoundRect(40, GY + 300, 84, ROWS * CELL_H - 320, 10, 10);
            g2.setColor(new Color(255, 220, 130));
            g2.fillOval(110, GY + 420, 7, 7);
        }

        private void drawMower(Graphics2D g2, int r) {
            if (!mowerAlive[r]) return;
            int mx = (int) mowerX[r], my = cellY(r) + CELL_H / 2;
            g2.setColor(new Color(0, 0, 0, 70));
            g2.fillOval(mx - 2, my + 12, 44, 10);
            g2.setPaint(new GradientPaint(mx, my - 16, new Color(230, 70, 55), mx, my + 8, new Color(150, 35, 28)));
            g2.fillRoundRect(mx, my - 16, 38, 24, 8, 8);
            g2.setColor(new Color(255, 140, 120, 130));
            g2.fillRoundRect(mx + 4, my - 13, 30, 8, 6, 6);
            g2.setColor(new Color(200, 200, 210));
            g2.fillRect(mx + 34, my - 8, 8, 14);
            g2.setColor(new Color(45, 45, 50));
            g2.fillOval(mx + 3, my + 6, 13, 13);
            g2.fillOval(mx + 21, my + 6, 13, 13);
            g2.setColor(new Color(120, 120, 128));
            g2.fillOval(mx + 6, my + 9, 7, 7);
            g2.fillOval(mx + 24, my + 9, 7, 7);
        }

        // ===== entities =====
        /** Sprites are pre-scaled ONCE per size and cached, so per-frame drawing is a plain blit. */
        private BufferedImage fitted(BufferedImage img, int maxW, int maxH) {
            long key = ((long) System.identityHashCode(img) << 32) | ((long) maxW << 16) | maxH;
            BufferedImage f = fitCache.get(key);
            if (f == null) {
                double s = Math.min((double) maxW / img.getWidth(), (double) maxH / img.getHeight());
                f = scaleHQ(img, Math.max(1, (int) (img.getWidth() * s)), Math.max(1, (int) (img.getHeight() * s)));
                fitCache.put(key, f);
            }
            return f;
        }

        /** Draw image anchored at bottom-center, preserving aspect ratio (no squishing). */
        private void drawImg(Graphics2D g, BufferedImage img, int maxW, int maxH) {
            if (img == null) return;
            BufferedImage f = fitted(img, maxW, maxH);
            g.drawImage(f, -f.getWidth() / 2, -f.getHeight(), null);
        }

        private void drawPlant(Graphics2D g2, Plant p) {
            int x = cellX(p.col) + CELL_W / 2;
            int baseY = cellY(p.row) + CELL_H - 12;

            long age = elapsed - p.plantedAt;
            double grow = Math.min(1.0, age / 400.0);
            double sway = Math.sin(elapsed / 450.0 + p.row * 1.7 + p.col * 0.9) * 0.09;

            Graphics2D g = (Graphics2D) g2.create();
            g.translate(x, baseY);
            g.scale(grow, grow);
            if (p.type == SeedType.CHERRYBOMB) {
                double pulse = 1.0 + 0.14 * Math.sin(elapsed / 90.0);
                g.scale(pulse, pulse);
            } else {
                g.rotate(sway);
            }

            // shadow
            g.setColor(new Color(0, 0, 0, 60));
            g.fillOval(-28, -6, 56, 13);

            switch (p.type) {
                case SUNFLOWER:
                    if (imgSun != null) { drawImg(g, imgSun, 80, 90); break; }
                    drawFallbackFlower(g);
                    break;
                case PEASHOOTER:
                    if (imgPea != null) { drawImg(g, imgPea, 80, 90); break; }
                    drawFallbackPea(g, new Color(70, 160, 60));
                    break;
                case SNOWPEA:
                    if (imgSnow != null) { drawImg(g, imgSnow, 80, 90); break; }
                    drawFallbackPea(g, new Color(110, 190, 235));
                    break;
                case REPEATER:
                    if (imgRepeater != null) { drawImg(g, imgRepeater, 84, 92); break; }
                    drawFallbackPea(g, new Color(45, 135, 55));
                    g.setColor(new Color(45, 135, 55));
                    g.fillRoundRect(2, -52, 30, 15, 8, 8);
                    break;
                case WALLNUT:
                    if (imgNut != null) { drawImg(g, imgNut, 72, 86); break; }
                    double hpFrac = p.hp / 4000.0;
                    g.setColor(hpFrac > 0.5 ? new Color(176, 126, 64) : hpFrac > 0.25 ? new Color(152, 102, 46) : new Color(126, 82, 36));
                    g.fillOval(-25, -62, 50, 62);
                    g.setColor(new Color(210, 170, 110, 90));
                    g.fillOval(-18, -56, 22, 26);
                    g.setColor(new Color(60, 40, 20));
                    g.fillOval(-11, -42, 6, 9);
                    g.fillOval(5, -42, 6, 9);
                    g.drawArc(-8, -24, 16, 10, 200, 140);
                    break;
                case CHERRYBOMB:
                    if (imgCherry != null) { drawImg(g, imgCherry, 80, 84); break; }
                    g.setColor(new Color(140, 30, 30));
                    g.fillOval(-30, -48, 30, 30);
                    g.fillOval(2, -48, 30, 30);
                    g.setColor(new Color(235, 60, 50));
                    g.fillOval(-27, -45, 24, 24);
                    g.fillOval(5, -45, 24, 24);
                    g.setColor(new Color(255, 150, 130, 160));
                    g.fillOval(-23, -42, 8, 8);
                    g.fillOval(9, -42, 8, 8);
                    g.setStroke(new BasicStroke(3f));
                    g.setColor(new Color(60, 110, 40));
                    g.drawLine(-14, -20, -6, -38);
                    g.drawLine(16, -20, 8, -38);
                    break;
            }

            // wall-nut damage cracks
            if (p.type == SeedType.WALLNUT && p.hp < p.maxHp * 0.5) {
                g.setColor(new Color(50, 32, 14, 160));
                g.setStroke(new BasicStroke(2f));
                g.drawLine(-10, -50, -2, -34);
                g.drawLine(-2, -34, -8, -20);
                if (p.hp < p.maxHp * 0.25) {
                    g.drawLine(12, -46, 6, -30);
                    g.drawLine(6, -30, 14, -14);
                }
            }
            g.dispose();
        }

        private void drawFallbackFlower(Graphics2D g) {
            g.setColor(new Color(90, 150, 50));
            g.fillRoundRect(-4, -34, 8, 34, 4, 4);
            for (int i = 0; i < 10; i++) {
                double a = i * Math.PI / 5;
                g.setColor(new Color(255, 205, 50));
                g.fillOval((int)(Math.cos(a) * 20) - 8, -46 + (int)(Math.sin(a) * 20) - 8, 16, 16);
            }
            g.setColor(new Color(140, 90, 30));
            g.fillOval(-14, -60, 28, 28);
            g.setColor(new Color(60, 40, 15));
            g.fillOval(-8, -54, 5, 5);
            g.fillOval(4, -54, 5, 5);
            g.drawArc(-6, -46, 12, 8, 200, 140);
        }

        private void drawFallbackPea(Graphics2D g, Color body) {
            g.setColor(body);
            g.fillOval(-22, -66, 44, 44);
            g.fillRoundRect(8, -58, 30, 18, 9, 9);
            g.setColor(body.darker());
            g.fillOval(-18, -34, 40, 32);
            g.fillOval(-28, -20, 22, 12);
            g.setColor(Color.BLACK);
            g.fillOval(2, -58, 7, 7);
            g.setColor(Color.WHITE);
            g.fillOval(4, -56, 3, 3);
        }

        private void drawZombie(Graphics2D g2, Zombie z) {
            int baseY = cellY(z.row) + CELL_H - 12;
            boolean slowed = elapsed < z.slowUntil;
            double t = z.animT;

            double bob = 0, rot = 0, sx = 1, sy = 1, lunge = 0;
            float alpha = 1f;

            if (z.dying) {
                double td = elapsed - z.dyingAt;
                double p = Math.min(1.0, td / 550.0);
                rot = (Math.PI / 2) * p * p;                       // topple backwards, accelerating
                if (td > 550) {
                    double q = Math.min(1.0, (td - 550) / 450.0);
                    alpha = (float) (1.0 - q);                     // fade out on the ground
                    bob = -Math.abs(Math.sin(q * Math.PI)) * 4;    // tiny landing bounce
                }
            } else if (z.eating) {
                double bite = Math.max(0, 1 - (elapsed - z.lastBite) / 180.0);
                rot = -0.10 + Math.sin(t / 85.0) * 0.05 - bite * 0.10;   // head-bob chewing + lunge
                lunge = -bite * 6;
                sy = 1 - bite * 0.03;
            } else {
                double step = Math.sin(t / 150.0 + z.phase);
                bob = -Math.abs(step) * 5;                                // shambling hop
                rot = -0.05 + Math.sin(t / 300.0 + z.phase) * 0.05;       // forward lean + sway
                sx = 1 + 0.02 * Math.cos(t / 150.0 + z.phase);
                sy = 1 - 0.02 * Math.abs(step);
            }

            // ground shadow (does not rotate)
            g2.setColor(new Color(0, 0, 0, (int) (70 * alpha)));
            g2.fillOval((int) z.x + 10 - 28, baseY - 4, 56, 12);

            Graphics2D g = (Graphics2D) g2.create();
            g.translate(z.x + 10 + lunge, baseY + bob);
            g.rotate(rot);
            g.scale(sx, sy);
            if (alpha < 1f) g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

            int tintW = 70, tintH = 112, tintX = -30;

            if (imgZombie != null) {
                BufferedImage f = fitted(imgZombie, 96, 128);
                int hw = f.getWidth(), hh = f.getHeight();
                g.drawImage(f, -hw / 2, -hh, null);
                tintW = hw; tintH = hh; tintX = -hw / 2;

                // headgear rides on the head so it animates with the sprite
                int hx = -hw / 2 + (int) (hw * 0.28);
                if (z.type == ZType.CONE) {
                    g.setColor(new Color(228, 138, 44));
                    Polygon cone = new Polygon();
                    cone.addPoint(hx, -hh - 22);
                    cone.addPoint(hx - 14, -hh + 8);
                    cone.addPoint(hx + 14, -hh + 8);
                    g.fillPolygon(cone);
                    g.setColor(new Color(255, 215, 150, 150));
                    g.drawLine(hx - 8, -hh - 4, hx + 8, -hh - 4);
                } else if (z.type == ZType.BUCKET) {
                    g.setPaint(new GradientPaint(0, -hh - 14, new Color(190, 195, 201), 0, -hh + 12, new Color(130, 136, 142)));
                    g.fillRoundRect(hx - 19, -hh - 14, 38, 26, 6, 6);
                    g.setColor(new Color(105, 110, 116));
                    g.drawLine(hx - 19, -hh - 1, hx + 19, -hh - 1);
                    g.setColor(new Color(255, 255, 255, 70));
                    g.fillRect(hx - 14, -hh - 10, 6, 18);
                }

                // white damage flash
                if (!z.dying && elapsed - z.hitAt < 100) {
                    Composite old = g.getComposite();
                    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f * alpha));
                    g.drawImage(silhouette(f), -hw / 2, -hh, null);
                    g.setComposite(old);
                }
            } else {
                // legs (walk cycle)
                double step = Math.sin(elapsed / 140.0 + z.row) * 8;
                g.setColor(new Color(70, 78, 62));
                g.fillRoundRect(-10 + (int) step, -22, 12, 22, 5, 5);
                g.fillRoundRect(6 - (int) step, -22, 12, 22, 5, 5);
                g.setPaint(new GradientPaint(0, -58, new Color(105, 126, 92), 0, -12, new Color(78, 96, 68)));
                g.fillRoundRect(-14, -60, 42, 42, 10, 10);
                g.setColor(new Color(60, 74, 52, 140));
                g.fillRect(-14, -34, 42, 8);
                g.setColor(new Color(105, 126, 92));
                g.fillRoundRect(-42, -50, 32, 11, 6, 6);
                g.fillRoundRect(-38, -34, 30, 11, 6, 6);
                g.setPaint(new GradientPaint(0, -92, new Color(138, 158, 120), 0, -58, new Color(110, 130, 95)));
                g.fillOval(-20, -94, 38, 36);
                g.setColor(new Color(96, 114, 82));
                g.fillRoundRect(-16, -66, 30, 10, 5, 5);
                g.setColor(new Color(245, 245, 225));
                g.fillOval(-10, -84, 9, 9);
                g.fillOval(6, -84, 9, 9);
                g.setColor(new Color(180, 30, 30));
                g.fillOval(-7, -81, 4, 4);
                g.fillOval(9, -81, 4, 4);
                if (z.type == ZType.CONE) {
                    g.setColor(new Color(228, 138, 44));
                    Polygon cone = new Polygon();
                    cone.addPoint(-1, -92);
                    cone.addPoint(-13, -122);
                    cone.addPoint(11, -122);
                    g.fillPolygon(cone);
                } else if (z.type == ZType.BUCKET) {
                    g.setPaint(new GradientPaint(0, -120, new Color(185, 190, 196), 0, -92, new Color(130, 136, 142)));
                    g.fillRoundRect(-18, -118, 36, 28, 6, 6);
                    g.setColor(new Color(105, 110, 116));
                    g.drawLine(-18, -104, 18, -104);
                }
            }

            // freeze tint
            if (slowed && !z.dying) {
                g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.28f));
                g.setColor(new Color(120, 200, 255));
                g.fillRoundRect(tintX, -tintH, tintW, tintH, 16, 16);
                g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                g.setColor(new Color(220, 245, 255));
                g.drawLine(tintX + 6, -tintH + 12, tintX + 18, -tintH + 12);
                g.drawLine(tintX + 12, -tintH + 6, tintX + 12, -tintH + 18);
            }
            g.dispose();

            // hp bar
            if (!z.dying) {
                double frac = Math.max(0, z.hp / (double) z.maxHp);
                int bx = (int) z.x - 16, by = cellY(z.row) + 8;
                g2.setColor(new Color(0, 0, 0, 130));
                g2.fillRoundRect(bx, by, 52, 6, 3, 3);
                g2.setColor(frac > 0.5 ? new Color(95, 225, 95) : frac > 0.25 ? new Color(245, 205, 65) : new Color(235, 75, 65));
                if (frac > 0) g2.fillRoundRect(bx + 1, by + 1, (int) (50 * frac), 4, 2, 2);
            }
        }

        private void drawSun(Graphics2D g2, SunDrop s) {
            float pulse = 1f + 0.08f * (float) Math.sin(elapsed / 200.0 + s.x);
            int r = (int) (26 * pulse);
            if (imgSunDrop != null) {
                g2.drawImage(fitted(imgSunDrop, 64, 64), (int) s.x - r, (int) s.y - r, r * 2, r * 2, null);
            } else {
                // rotating rays
                g2.setColor(new Color(255, 215, 60, 90));
                for (int i = 0; i < 8; i++) {
                    double a = elapsed / 600.0 + i * Math.PI / 4;
                    int x1 = (int) (s.x + Math.cos(a) * (r + 4));
                    int y1 = (int) (s.y + Math.sin(a) * (r + 4));
                    int x2 = (int) (s.x + Math.cos(a) * (r + 13));
                    int y2 = (int) (s.y + Math.sin(a) * (r + 13));
                    g2.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawLine(x1, y1, x2, y2);
                }
                RadialGradientPaint glow = new RadialGradientPaint(
                        new Point((int) s.x, (int) s.y), r + 14,
                        new float[]{0f, 1f},
                        new Color[]{new Color(255, 220, 60, 110), new Color(255, 220, 60, 0)});
                g2.setPaint(glow);
                g2.fillOval((int) s.x - r - 14, (int) s.y - r - 14, (r + 14) * 2, (r + 14) * 2);
                g2.setColor(new Color(255, 215, 60));
                g2.fillOval((int) s.x - r, (int) s.y - r, r * 2, r * 2);
                g2.setColor(new Color(255, 245, 170));
                g2.fillOval((int) s.x - r / 2, (int) s.y - r / 2, r, r);
            }
        }

        private void drawCollectible(Graphics2D g2, Collectible k) {
            int x = (int) k.x, y = (int) k.y;
            float bob = (float) Math.sin(elapsed / 250.0 + k.x) * 3f;
            g2.setColor(new Color(0, 0, 0, 60));
            g2.fillOval(x - 12, y + 12, 24, 7);
            switch (k.type) {
                case COIN10: case COIN25: {
                    g2.setPaint(new GradientPaint(x, y - 14 + bob, new Color(255, 230, 120), x, y + 12 + bob, new Color(200, 150, 30)));
                    g2.fillOval(x - 13, (int)(y - 13 + bob), 26, 26);
                    g2.setColor(new Color(170, 120, 20));
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawOval(x - 13, (int)(y - 13 + bob), 26, 26);
                    g2.setFont(new Font("Arial", Font.BOLD, 12));
                    g2.setColor(new Color(140, 95, 10));
                    String v = k.type == CollectType.COIN10 ? "10" : "25";
                    g2.drawString(v, x - g2.getFontMetrics().stringWidth(v) / 2, (int)(y + 4 + bob));
                    break;
                }
                case GEM50: {
                    Polygon gem = new Polygon();
                    int gy = (int)(y + bob);
                    gem.addPoint(x, gy - 16); gem.addPoint(x + 13, gy - 4);
                    gem.addPoint(x, gy + 14); gem.addPoint(x - 13, gy - 4);
                    g2.setPaint(new GradientPaint(x, gy - 16, new Color(210, 180, 255), x, gy + 14, new Color(120, 70, 220)));
                    g2.fillPolygon(gem);
                    g2.setColor(new Color(255, 255, 255, 130));
                    g2.drawLine(x - 5, gy - 8, x + 2, gy - 12);
                    break;
                }
                case SUN50: {
                    g2.setColor(new Color(255, 235, 120));
                    g2.fillOval(x - 14, (int)(y - 14 + bob), 28, 28);
                    g2.setColor(new Color(255, 255, 220));
                    g2.fillOval(x - 7, (int)(y - 7 + bob), 14, 14);
                    g2.setFont(new Font("Arial", Font.BOLD, 11));
                    g2.setColor(new Color(160, 120, 10));
                    g2.drawString("+50", x - 10, (int)(y + 4 + bob));
                    break;
                }
            }
        }

        private void drawHUD(Graphics2D g2, int W) {
            // glass panel
            g2.setPaint(new GradientPaint(0, 14, new Color(20, 34, 20, 225), 0, 72, new Color(10, 20, 10, 215)));
            g2.fillRoundRect(16, 14, W - 32, 58, 16, 16);
            g2.setPaint(new GradientPaint(0, 14, new Color(160, 255, 140, 90), W, 14, new Color(120, 200, 255, 50)));
            g2.setStroke(new BasicStroke(1.6f));
            g2.drawRoundRect(16, 14, W - 32, 58, 16, 16);

            // sun counter
            if (imgSunDrop != null) g2.drawImage(fitted(imgSunDrop, 34, 34), 34, 24, null);
            else {
                g2.setColor(new Color(255, 215, 60));
                g2.fillOval(38, 27, 30, 30);
                g2.setColor(new Color(255, 245, 170));
                g2.fillOval(46, 35, 14, 14);
            }
            g2.setFont(new Font("Arial", Font.BOLD, 24));
            g2.setColor(Color.WHITE);
            g2.drawString(String.valueOf(sun), 78, 52);

            // coins
            g2.setPaint(new GradientPaint(150, 27, new Color(255, 230, 120), 150, 57, new Color(200, 150, 30)));
            g2.fillOval(150, 28, 26, 26);
            g2.setColor(new Color(170, 120, 20));
            g2.drawOval(150, 28, 26, 26);
            g2.setFont(new Font("Arial", Font.BOLD, 20));
            g2.setColor(new Color(255, 230, 140));
            g2.drawString(String.valueOf(coins), 184, 50);

            // wave progress
            int bx = 300, bw = 480, by = 32;
            g2.setFont(new Font("Arial", Font.BOLD, 13));
            g2.setColor(new Color(170, 200, 170));
            g2.drawString("LEVEL " + (levelIdx + 1) + " — " + cfg.name, bx, by - 4);
            g2.setColor(new Color(255, 255, 255, 45));
            g2.fillRoundRect(bx, by, bw, 12, 6, 6);
            double frac = cfg.zombieCount == 0 ? 0 : (double) killed / cfg.zombieCount;
            g2.setPaint(new GradientPaint(bx, by, new Color(120, 230, 90), bx + bw, by, new Color(230, 90, 70)));
            g2.fillRoundRect(bx, by, (int)(bw * frac), 12, 6, 6);
            g2.setColor(new Color(200, 220, 200));
            g2.drawString("Zombies down: " + killed + " / " + cfg.zombieCount, bx, by + 30);

            // XP mini-bar
            int xb = 810, xw = 250;
            g2.setColor(new Color(255, 255, 255, 45));
            g2.fillRoundRect(xb, by, xw, 10, 5, 5);
            g2.setPaint(new GradientPaint(xb, by, new Color(120, 190, 255), xb + xw, by, new Color(170, 120, 255)));
            g2.fillRoundRect(xb, by, (int)(xw * Math.min(1, xp / (double) xpToNext())), 10, 5, 5);
            g2.setColor(new Color(180, 210, 240));
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            g2.drawString("LV " + playerLevel + "  " + xp + "/" + xpToNext() + " XP", xb, by + 27);

            // menu button
            boolean menuHover = menuBtn.contains(hoverX, hoverY);
            g2.setPaint(new GradientPaint(menuBtn.x, menuBtn.y,
                    menuHover ? new Color(220, 100, 88) : new Color(190, 80, 70),
                    menuBtn.x, menuBtn.y + menuBtn.height, new Color(130, 50, 42)));
            g2.fillRoundRect(menuBtn.x, menuBtn.y, menuBtn.width, menuBtn.height, 12, 12);
            g2.setFont(new Font("Arial", Font.BOLD, 14));
            g2.setColor(Color.WHITE);
            String m = "MENU";
            g2.drawString(m, menuBtn.x + (menuBtn.width - g2.getFontMetrics().stringWidth(m)) / 2, menuBtn.y + 26);
        }

        private void drawSeedBar(Graphics2D g2) {
            seedCards.clear();
            SeedType[] types = SeedType.values();
            for (int i = 0; i < types.length; i++) {
                int x = 20 + i * 132, y = 88, w = 124, h = 88;
                Rectangle r = new Rectangle(x, y, w, h);
                seedCards.add(r);
                boolean afford = sun >= types[i].cost;
                boolean sel = selected == types[i];
                boolean hov = r.contains(hoverX, hoverY);

                // card bg
                g2.setPaint(new GradientPaint(0, y, sel ? new Color(60, 90, 45, 240) : hov ? new Color(34, 52, 32, 240) : new Color(20, 32, 20, 225),
                        0, y + h, new Color(14, 24, 14, 225)));
                g2.fillRoundRect(x, y, w, h, 14, 14);
                g2.setColor(sel ? new Color(220, 255, 150) : new Color(120, 180, 110, afford ? (hov ? 190 : 130) : 50));
                g2.setStroke(new BasicStroke(sel ? 3f : 1.5f));
                g2.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 14, 14);

                // key hint badge
                g2.setColor(new Color(0, 0, 0, 120));
                g2.fillRoundRect(x + w - 20, y + 5, 15, 15, 4, 4);
                g2.setFont(new Font("Arial", Font.BOLD, 10));
                g2.setColor(new Color(200, 230, 200));
                g2.drawString(String.valueOf(i + 1), x + w - 15, y + 16);

                if (!afford) g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.35f));
                Graphics2D g = (Graphics2D) g2.create();
                g.translate(x + w / 2, y + 60);
                double sway = Math.sin(elapsed / 450.0 + i) * 0.06;
                g.rotate(sway);
                switch (types[i]) {
                    case SUNFLOWER:
                        if (imgSun != null) drawImg(g, imgSun, 48, 52);
                        else { g.setColor(new Color(255,205,50)); g.fillOval(-16, -44, 32, 32); g.setColor(new Color(140,90,30)); g.fillOval(-8, -36, 16, 16); }
                        break;
                    case PEASHOOTER:
                        if (imgPea != null) drawImg(g, imgPea, 48, 52);
                        else { g.setColor(new Color(70,160,60)); g.fillOval(-14, -42, 28, 26); g.fillRoundRect(4, -38, 18, 11, 6, 6); }
                        break;
                    case SNOWPEA:
                        if (imgSnow != null) drawImg(g, imgSnow, 48, 52);
                        else { g.setColor(new Color(110,190,235)); g.fillOval(-14, -42, 28, 26); g.fillRoundRect(4, -38, 18, 11, 6, 6); }
                        break;
                    case REPEATER:
                        if (imgRepeater != null) drawImg(g, imgRepeater, 52, 54);
                        else { g.setColor(new Color(45,135,55)); g.fillOval(-16, -42, 30, 26); g.fillRoundRect(2, -40, 20, 10, 5, 5); g.fillRoundRect(2, -28, 20, 10, 5, 5); }
                        break;
                    case WALLNUT:
                        if (imgNut != null) drawImg(g, imgNut, 46, 52);
                        else { g.setColor(new Color(170,120,60)); g.fillOval(-14, -46, 28, 42); }
                        break;
                    case CHERRYBOMB:
                        if (imgCherry != null) drawImg(g, imgCherry, 52, 52);
                        else {
                            g.setColor(new Color(235, 60, 50));
                            g.fillOval(-24, -38, 24, 24);
                            g.fillOval(2, -38, 24, 24);
                        }
                        break;
                }
                g.dispose();
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

                g2.setFont(new Font("Arial", Font.BOLD, 11));
                g2.setColor(afford ? Color.WHITE : Color.GRAY);
                g2.drawString(shortName(types[i]), x + 8, y + h - 8);
                g2.setColor(new Color(255, 215, 60));
                g2.fillOval(x + w - 44, y + h - 20, 10, 10);
                g2.drawString(String.valueOf(types[i].cost), x + w - 30, y + h - 8);
            }
            g2.setFont(new Font("Arial", Font.PLAIN, 12));
            g2.setColor(new Color(200, 220, 200, 170));
            g2.drawString(selected == null ? "Pick a seed, then click a tile  (keys 1-6, ESC)"
                    : "Placing: " + selected.name() + " (click a tile)", 20, 196);
        }

        private String shortName(SeedType t) {
            switch (t) {
                case PEASHOOTER: return "PEA";
                case SUNFLOWER:  return "SUN";
                case WALLNUT:    return "NUT";
                case SNOWPEA:    return "ICE";
                case REPEATER:   return "DUAL";
                case CHERRYBOMB: return "BOMB";
            }
            return t.name();
        }

        private void drawEndOverlay(Graphics2D g2, boolean won) {
            int W = getWidth(), H = getHeight();
            g2.setColor(new Color(0, 0, 0, 175));
            g2.fillRect(0, 0, W, H);
            int cx = W / 2, cy = H / 2;

            g2.setFont(new Font("Impact", Font.PLAIN, 64));
            String t = won ? "LEVEL COMPLETE!" : "THE ZOMBIES ATE YOUR BRAINS";
            g2.setColor(won ? new Color(190, 255, 110) : new Color(240, 90, 80));
            g2.drawString(t, cx - g2.getFontMetrics().stringWidth(t) / 2, cy - 60);

            if (won) {
                int starCount = anyMowerLost ? (mowersLostCount() == 1 ? 2 : 1) : 3;
                g2.setFont(new Font("Arial", Font.PLAIN, 52));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 3; i++) sb.append(i < starCount ? "★" : "☆");
                g2.setColor(new Color(255, 215, 0));
                String s = sb.toString();
                g2.drawString(s, cx - g2.getFontMetrics().stringWidth(s) / 2, cy + 10);
                g2.setFont(new Font("Arial", Font.BOLD, 16));
                g2.setColor(new Color(170, 210, 255));
                g2.drawString("+" + (50 + starCount * 25) + " XP earned!", cx - 70, cy + 48);
            }

            drawOverlayBtn(g2, cx - 220, cy + 90, 140, 52, "RETRY", new Color(80,140,220), new Color(45,90,170));
            if (won && levelIdx < 4)
                drawOverlayBtn(g2, cx - 70, cy + 90, 140, 52, "NEXT", new Color(70,180,90), new Color(40,130,60));
            drawOverlayBtn(g2, cx + 80, cy + 90, 140, 52, "MENU", new Color(170,70,70), new Color(120,45,45));
        }

        private void drawOverlayBtn(Graphics2D g2, int x, int y, int w, int h, String text, Color a, Color b) {
            g2.setPaint(new GradientPaint(x, y, a, x, y + h, b));
            g2.fillRoundRect(x, y, w, h, 14, 14);
            g2.setColor(new Color(0, 0, 0, 90));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 13, 13);
            g2.setFont(new Font("Arial", Font.BOLD, 16));
            g2.setColor(Color.WHITE);
            g2.drawString(text, x + (w - g2.getFontMetrics().stringWidth(text)) / 2, y + 32);
        }

        // ---------- entities ----------
        class Plant {
            int row, col; SeedType type; int hp, maxHp;
            long lastAction, plantedAt; boolean pendingSecond;
            Plant(int r, int c, SeedType t) {
                row = r; col = c; type = t;
                maxHp = hp = t == SeedType.WALLNUT ? 4000 : 300;
                plantedAt = elapsed;
                lastAction = elapsed - (t == SeedType.SUNFLOWER ? 3500 : 0);
            }
        }
        class Zombie {
            int row; double x; ZType type; int hp, maxHp; long lastBite, slowUntil;
            boolean dying, eating;
            long dyingAt, hitAt;
            double animT, phase;
            Zombie(int row, double x, ZType t, int hp) {
                this.row = row; this.x = x; this.type = t; this.hp = hp; this.maxHp = hp;
                this.lastBite = 0; this.slowUntil = 0;
                this.phase = Math.random() * Math.PI * 2;
                this.animT = Math.random() * 1000;
                this.hitAt = -10000;
            }
        }
        class Pea {
            double x, y; int row; int dmg; boolean ice;
            Pea(double x, double y, int row, int dmg, boolean ice) {
                this.x = x; this.y = y; this.row = row; this.dmg = dmg; this.ice = ice;
            }
        }
        class SunDrop {
            double x, y, targetY; long landedAt;
            SunDrop(double x, double y, double targetY, boolean fromSky) {
                this.x = x; this.y = y; this.targetY = targetY; this.landedAt = 0;
            }
        }
        class Collectible {
            CollectType type; double x, y, targetY; long landedAt;
            Collectible(CollectType type, double x, double y, double targetY) {
                this.type = type; this.x = x; this.y = y; this.targetY = targetY; this.landedAt = 0;
            }
        }
        class Shockwave {
            int x, y, r, life;
            Shockwave(int x, int y, int r) { this.x = x; this.y = y; this.r = r; this.life = 30; }
        }
        class Particle {
            double x, y, vx, vy; int life; Color c;
            Particle(double x, double y, double vx, double vy, int life, Color c) {
                this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.life = life; this.c = c;
            }
        }
    }

    // ===================== ENTRY =====================
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new main().setVisible(true));
    }
}

interface GameCallback {
    void onLevelComplete(int levelIdx, int starCount, int kills, long sunCollected);
    void onGameExit();
    default void onKill() {}
    default void onCollect(int coins, int sun) {}
}